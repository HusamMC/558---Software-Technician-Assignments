﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

namespace Lab2Part2
{
    /// <summary>
    /// Represents the main form of the application.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initializes a new instance of the form1 class.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the Load event of the form.
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            // Initialization code can be placed here if needed
        }

        /// <summary>
        /// Handles the Click event of the exit button.
        /// Closes the application.
        /// </summary>
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Handles the Click event of the calculate button.
        /// Validates input, calculates the total price, and displays it.
        /// </summary>
        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Validate input for the number of visits
            if (!int.TryParse(visitText.Text, out int numberOfVisits) || numberOfVisits <= 0)
            {
                MessageBox.Show("Please enter a valid positive integer for Number of Visits.");
                visitText.Focus();
                return;
            }

            // Step 2: Select Hairdresser and get base rate
            int baseRate = 0;

            if (janebutton.Checked)
                baseRate = 30;
            else if (patButton.Checked)
                baseRate = 45;
            else if (ronButton.Checked)
                baseRate = 40;
            else if (sueButton.Checked)
                baseRate = 50;
            else if (lauraButton.Checked)
                baseRate = 55;
            else
            {
                MessageBox.Show("Please select a hairdresser.");
                janebutton.Focus(); // Set focus to the first hairdresser
                return;
            }

            // Step 3: Select Services and calculate service total
            int serviceTotal = 0;

            if (cutBox.Checked) serviceTotal += 30;
            if (colourBox.Checked) serviceTotal += 40;
            if (highlightBox.Checked) serviceTotal += 50;
            if (extensionsBox.Checked) serviceTotal += 200;

            // Ensure at least one service is selected
            if (serviceTotal == 0)
            {
                MessageBox.Show("Please select at least one service.");
                cutBox.Focus(); // Set focus to the first service checkbox
                return;
            }

            // Step 4: Calculate discounts
            int discountRate = 0;

            if (childButton.Checked) discountRate += 10;
            else if (studentButton.Checked) discountRate += 5;
            else if (seniorButton.Checked) discountRate += 15;

            // Step 5: Additional visits discount
            if (numberOfVisits >= 4 && numberOfVisits <= 8) discountRate += 5;
            else if (numberOfVisits >= 9 && numberOfVisits <= 13) discountRate += 10;
            else if (numberOfVisits >= 14) discountRate += 15;

            // Step 6: Calculate total price
            int totalPrice = baseRate + serviceTotal;
            totalPrice -= totalPrice * discountRate / 100; // Apply discount

            // Step 7: Display the total price
            displayPrice.Text = totalPrice.ToString("C");
        }

        /// <summary>
        /// Handles the Click event of the clear button.
        /// Resets all controls to their default state.
        /// </summary>
        private void clearButton_Click(object sender, EventArgs e)
        {
            // Reset Hairdresser 
            janebutton.Checked = true;
            janebutton.Focus();

            // Reset Services
            cutBox.Checked = false;
            colourBox.Checked = false;
            highlightBox.Checked = false;
            extensionsBox.Checked = false;

            // Reset Client Type 
            adultButton.Checked = true;

            // Clear the Visits TextBox
            visitText.Clear();

            // Reset the Total Price label
            displayPrice.Text = "$0.00";
        }
    }
}
