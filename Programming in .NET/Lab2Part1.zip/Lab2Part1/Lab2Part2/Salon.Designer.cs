﻿namespace Lab2Part2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hairDresser = new System.Windows.Forms.GroupBox();
            this.lauraButton = new System.Windows.Forms.RadioButton();
            this.sueButton = new System.Windows.Forms.RadioButton();
            this.ronButton = new System.Windows.Forms.RadioButton();
            this.patButton = new System.Windows.Forms.RadioButton();
            this.janebutton = new System.Windows.Forms.RadioButton();
            this.servicesBox = new System.Windows.Forms.GroupBox();
            this.extensionsBox = new System.Windows.Forms.CheckBox();
            this.highlightBox = new System.Windows.Forms.CheckBox();
            this.colourBox = new System.Windows.Forms.CheckBox();
            this.cutBox = new System.Windows.Forms.CheckBox();
            this.clientType = new System.Windows.Forms.GroupBox();
            this.seniorButton = new System.Windows.Forms.RadioButton();
            this.studentButton = new System.Windows.Forms.RadioButton();
            this.childButton = new System.Windows.Forms.RadioButton();
            this.adultButton = new System.Windows.Forms.RadioButton();
            this.clientVisits = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.visitText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.displayPrice = new System.Windows.Forms.Label();
            this.hairDresser.SuspendLayout();
            this.servicesBox.SuspendLayout();
            this.clientType.SuspendLayout();
            this.clientVisits.SuspendLayout();
            this.SuspendLayout();
            // 
            // hairDresser
            // 
            this.hairDresser.Controls.Add(this.lauraButton);
            this.hairDresser.Controls.Add(this.sueButton);
            this.hairDresser.Controls.Add(this.ronButton);
            this.hairDresser.Controls.Add(this.patButton);
            this.hairDresser.Controls.Add(this.janebutton);
            this.hairDresser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hairDresser.Location = new System.Drawing.Point(28, 12);
            this.hairDresser.Name = "hairDresser";
            this.hairDresser.Size = new System.Drawing.Size(213, 230);
            this.hairDresser.TabIndex = 0;
            this.hairDresser.TabStop = false;
            this.hairDresser.Text = "Hairdresser";
            // 
            // lauraButton
            // 
            this.lauraButton.AutoSize = true;
            this.lauraButton.Location = new System.Drawing.Point(17, 179);
            this.lauraButton.Name = "lauraButton";
            this.lauraButton.Size = new System.Drawing.Size(124, 20);
            this.lauraButton.TabIndex = 4;
            this.lauraButton.Text = "Laura Renkins";
            this.lauraButton.UseVisualStyleBackColor = true;
            // 
            // sueButton
            // 
            this.sueButton.AutoSize = true;
            this.sueButton.Location = new System.Drawing.Point(17, 140);
            this.sueButton.Name = "sueButton";
            this.sueButton.Size = new System.Drawing.Size(100, 20);
            this.sueButton.TabIndex = 3;
            this.sueButton.Text = "Sue Pallon";
            this.sueButton.UseVisualStyleBackColor = true;
            // 
            // ronButton
            // 
            this.ronButton.AutoSize = true;
            this.ronButton.Location = new System.Drawing.Point(17, 101);
            this.ronButton.Name = "ronButton";
            this.ronButton.Size = new System.Drawing.Size(127, 20);
            this.ronButton.TabIndex = 2;
            this.ronButton.Text = "Ron Chambers";
            this.ronButton.UseVisualStyleBackColor = true;
            // 
            // patButton
            // 
            this.patButton.AutoSize = true;
            this.patButton.Location = new System.Drawing.Point(17, 62);
            this.patButton.Name = "patButton";
            this.patButton.Size = new System.Drawing.Size(110, 20);
            this.patButton.TabIndex = 1;
            this.patButton.Text = "Pat Johnson";
            this.patButton.UseVisualStyleBackColor = true;
            // 
            // janebutton
            // 
            this.janebutton.AutoSize = true;
            this.janebutton.Checked = true;
            this.janebutton.Location = new System.Drawing.Point(20, 23);
            this.janebutton.Name = "janebutton";
            this.janebutton.Size = new System.Drawing.Size(115, 20);
            this.janebutton.TabIndex = 0;
            this.janebutton.TabStop = true;
            this.janebutton.Text = "Jane Samley";
            this.janebutton.UseVisualStyleBackColor = true;
            // 
            // servicesBox
            // 
            this.servicesBox.Controls.Add(this.extensionsBox);
            this.servicesBox.Controls.Add(this.highlightBox);
            this.servicesBox.Controls.Add(this.colourBox);
            this.servicesBox.Controls.Add(this.cutBox);
            this.servicesBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.servicesBox.Location = new System.Drawing.Point(316, 12);
            this.servicesBox.Name = "servicesBox";
            this.servicesBox.Size = new System.Drawing.Size(213, 230);
            this.servicesBox.TabIndex = 1;
            this.servicesBox.TabStop = false;
            this.servicesBox.Text = "Services";
            // 
            // extensionsBox
            // 
            this.extensionsBox.AutoSize = true;
            this.extensionsBox.Location = new System.Drawing.Point(18, 141);
            this.extensionsBox.Name = "extensionsBox";
            this.extensionsBox.Size = new System.Drawing.Size(101, 20);
            this.extensionsBox.TabIndex = 3;
            this.extensionsBox.Text = "Extensions";
            this.extensionsBox.UseVisualStyleBackColor = true;
            // 
            // highlightBox
            // 
            this.highlightBox.AutoSize = true;
            this.highlightBox.Location = new System.Drawing.Point(18, 102);
            this.highlightBox.Name = "highlightBox";
            this.highlightBox.Size = new System.Drawing.Size(95, 20);
            this.highlightBox.TabIndex = 2;
            this.highlightBox.Text = "Highlights";
            this.highlightBox.UseVisualStyleBackColor = true;
            // 
            // colourBox
            // 
            this.colourBox.AutoSize = true;
            this.colourBox.Location = new System.Drawing.Point(18, 63);
            this.colourBox.Name = "colourBox";
            this.colourBox.Size = new System.Drawing.Size(71, 20);
            this.colourBox.TabIndex = 1;
            this.colourBox.Text = "Colour";
            this.colourBox.UseVisualStyleBackColor = true;
            // 
            // cutBox
            // 
            this.cutBox.AutoSize = true;
            this.cutBox.Location = new System.Drawing.Point(18, 24);
            this.cutBox.Name = "cutBox";
            this.cutBox.Size = new System.Drawing.Size(48, 20);
            this.cutBox.TabIndex = 0;
            this.cutBox.Text = "Cut";
            this.cutBox.UseVisualStyleBackColor = true;
            // 
            // clientType
            // 
            this.clientType.Controls.Add(this.seniorButton);
            this.clientType.Controls.Add(this.studentButton);
            this.clientType.Controls.Add(this.childButton);
            this.clientType.Controls.Add(this.adultButton);
            this.clientType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientType.Location = new System.Drawing.Point(28, 263);
            this.clientType.Name = "clientType";
            this.clientType.Size = new System.Drawing.Size(213, 201);
            this.clientType.TabIndex = 1;
            this.clientType.TabStop = false;
            this.clientType.Text = "Client Type";
            // 
            // seniorButton
            // 
            this.seniorButton.AutoSize = true;
            this.seniorButton.Location = new System.Drawing.Point(15, 151);
            this.seniorButton.Name = "seniorButton";
            this.seniorButton.Size = new System.Drawing.Size(135, 20);
            this.seniorButton.TabIndex = 8;
            this.seniorButton.Text = "Senior (over 65)";
            this.seniorButton.UseVisualStyleBackColor = true;
            // 
            // studentButton
            // 
            this.studentButton.AutoSize = true;
            this.studentButton.Location = new System.Drawing.Point(15, 110);
            this.studentButton.Name = "studentButton";
            this.studentButton.Size = new System.Drawing.Size(77, 20);
            this.studentButton.TabIndex = 7;
            this.studentButton.Text = "Student";
            this.studentButton.UseVisualStyleBackColor = true;
            // 
            // childButton
            // 
            this.childButton.AutoSize = true;
            this.childButton.Location = new System.Drawing.Point(15, 69);
            this.childButton.Name = "childButton";
            this.childButton.Size = new System.Drawing.Size(166, 20);
            this.childButton.TabIndex = 6;
            this.childButton.Text = "Child (12 and Under)";
            this.childButton.UseVisualStyleBackColor = true;
            // 
            // adultButton
            // 
            this.adultButton.AutoSize = true;
            this.adultButton.Checked = true;
            this.adultButton.Location = new System.Drawing.Point(15, 28);
            this.adultButton.Name = "adultButton";
            this.adultButton.Size = new System.Drawing.Size(127, 20);
            this.adultButton.TabIndex = 5;
            this.adultButton.TabStop = true;
            this.adultButton.Text = "Standard Adult";
            this.adultButton.UseVisualStyleBackColor = true;
            // 
            // clientVisits
            // 
            this.clientVisits.Controls.Add(this.label1);
            this.clientVisits.Controls.Add(this.visitText);
            this.clientVisits.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clientVisits.Location = new System.Drawing.Point(316, 263);
            this.clientVisits.Name = "clientVisits";
            this.clientVisits.Size = new System.Drawing.Size(213, 201);
            this.clientVisits.TabIndex = 1;
            this.clientVisits.TabStop = false;
            this.clientVisits.Text = "Client Visits";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Number of Client Visits:";
            // 
            // visitText
            // 
            this.visitText.Location = new System.Drawing.Point(18, 61);
            this.visitText.Name = "visitText";
            this.visitText.Size = new System.Drawing.Size(164, 22);
            this.visitText.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(154, 480);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Total Price:";
            // 
            // calculateButton
            // 
            this.calculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateButton.Location = new System.Drawing.Point(28, 548);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(114, 48);
            this.calculateButton.TabIndex = 3;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(217, 548);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(114, 48);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(415, 548);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(114, 48);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // displayPrice
            // 
            this.displayPrice.AutoSize = true;
            this.displayPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayPrice.Location = new System.Drawing.Point(241, 480);
            this.displayPrice.Name = "displayPrice";
            this.displayPrice.Size = new System.Drawing.Size(0, 16);
            this.displayPrice.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(557, 608);
            this.Controls.Add(this.displayPrice);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.clientVisits);
            this.Controls.Add(this.clientType);
            this.Controls.Add(this.servicesBox);
            this.Controls.Add(this.hairDresser);
            this.Name = "Form1";
            this.Text = "Sam\'s Super Salon";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.hairDresser.ResumeLayout(false);
            this.hairDresser.PerformLayout();
            this.servicesBox.ResumeLayout(false);
            this.servicesBox.PerformLayout();
            this.clientType.ResumeLayout(false);
            this.clientType.PerformLayout();
            this.clientVisits.ResumeLayout(false);
            this.clientVisits.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox hairDresser;
        private System.Windows.Forms.GroupBox servicesBox;
        private System.Windows.Forms.GroupBox clientType;
        private System.Windows.Forms.GroupBox clientVisits;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox visitText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton lauraButton;
        private System.Windows.Forms.RadioButton sueButton;
        private System.Windows.Forms.RadioButton ronButton;
        private System.Windows.Forms.RadioButton patButton;
        private System.Windows.Forms.RadioButton janebutton;
        private System.Windows.Forms.RadioButton seniorButton;
        private System.Windows.Forms.RadioButton studentButton;
        private System.Windows.Forms.RadioButton childButton;
        private System.Windows.Forms.RadioButton adultButton;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.CheckBox extensionsBox;
        private System.Windows.Forms.CheckBox highlightBox;
        private System.Windows.Forms.CheckBox colourBox;
        private System.Windows.Forms.CheckBox cutBox;
        private System.Windows.Forms.Label displayPrice;
    }
}

