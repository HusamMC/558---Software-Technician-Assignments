﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;

namespace Lab2
{
    /// <summary>
    /// Represents a box shape.
    /// </summary>
    public class Box : Shape
    {
        /// <summary>
        /// Gets or sets the width of the box.
        /// </summary>
        public double Width { get; set; }
        /// <summary>
        /// Gets or sets the height of the box.
        /// </summary>
        public double Height { get; set; }
        /// <summary>
        /// Gets or sets the depth of the box.
        /// </summary>
        public double Depth { get; set; }

        /// <summary>
        /// Initializes a new instance of the box class.
        /// </summary>
        public Box()
        {
            Type = "Box";
        }
        /// <summary>
        /// Calculates the Area of the box.
        /// </summary>
        public override double CalculateArea() => 2 * (Width * Height + Height * Depth + Width * Depth);
        /// <summary>
        /// Calculates the volume of the box.
        /// </summary>
        public override double CalculateVolume() => Width * Height * Depth;
        /// <summary>
        /// Prompts the user to enter the dimensions of the box.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter width: ");
            Width = GetValidDouble();
            Console.Write("Enter height: ");
            Height = GetValidDouble();
            Console.Write("Enter depth: ");
            Depth = GetValidDouble();
        }

        /// <summary>
        /// Returns a string representation of the box.
        /// </summary>
        /// <returns>A string with dimensions and area of the box.</returns>
        public override string ToString()
        {
            return $"{Type} - Width: {Width}, Height: {Height}, Depth: {Depth}, Area: {CalculateArea()}, Volume: {CalculateVolume()}";
        }

        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
