﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;

namespace Lab2
{
    /// <summary>
    /// Represents a cube shape.
    /// </summary>
    public class Cube : Box
    {
        /// <summary>
        /// Initializes a new instance of the Cube class.
        /// </summary>
        public Cube()
        {
            Type = "Cube";
        }

        /// <summary>
        /// Prompts the user to enter the dimensions of the cube.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter side length: ");
            double side = GetValidDouble();
            Width = Height = Depth = side; // All sides are equal
        }

        /// <summary>
        /// Returns a string representation of the cube.
        /// </summary>
        /// <returns>A string with the side length, area, and volume of the cube.</returns>
        public override string ToString()
        {
            return $"{Type} - Side: {Width}, Area: {CalculateArea()}, Volume: {CalculateVolume()}";
        }
        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
