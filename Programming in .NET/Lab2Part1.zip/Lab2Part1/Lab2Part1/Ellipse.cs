﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;

namespace Lab2
{
    /// <summary>
    /// Represents a ellipse shape.
    /// </summary>
    public class Ellipse : Shape
    {
        /// <summary>
        /// Gets or sets the majoraxis of the ellipse.
        /// </summary>
        public double MajorAxis { get; set; }
        /// <summary>
        /// Gets or sets the minoraxis of the ellipse.
        /// </summary>
        public double MinorAxis { get; set; }
        /// <summary>
        /// Initializes a new instance of the ellipse class.
        /// </summary>
        public Ellipse()
        {
            Type = "Ellipse";
        }
        /// <summary>
        /// Calculates the area of the ellipse.
        /// </summary>
        public override double CalculateArea() => PI * MajorAxis * MinorAxis;
        /// <summary>
        /// Calculates the volume of the ellipse.
        /// </summary>
        public override double CalculateVolume() => 0; // Not a 3D shape
        /// <summary>
        /// Prompts the user to enter the dimensions of the ellipse.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter major axis: ");
            MajorAxis = GetValidDouble();
            Console.Write("Enter minor axis: ");
            MinorAxis = GetValidDouble();
        }

        /// <summary>
        /// Returns a string representation of the ellipse.
        /// </summary>
        /// <returns>A string with dimensions and area of the ellipse.</returns>
        public override string ToString()
        {
            return $"{Type} - Major Axis: {MajorAxis}, Minor Axis: {MinorAxis}, Area: {CalculateArea()}";
        }
        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
