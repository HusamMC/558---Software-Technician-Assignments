﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;

namespace Lab2
{
    /// <summary>
    /// Represents a circle shape.
    /// </summary>
    public class Circle : Shape
    {
        /// <summary>
        /// Gets or sets the radius of the circle.
        /// </summary>
        public double Radius { get; set; }
        /// <summary>
        /// Initializes a new instance of the circle class.
        /// </summary>
        public Circle()
        {
            Type = "Circle";
        }
        /// <summary>
        /// Calculates the area of the circle.
        /// </summary>
        public override double CalculateArea() => PI * Radius * Radius;
        /// <summary>
        /// Calculates the volume of the circle.
        /// </summary>
        public override double CalculateVolume() => 0; // Not a 3D shape
        /// <summary>
        /// Prompts the user to enter the dimensions of the circle.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter radius: ");
            Radius = GetValidDouble();
        }

        /// <summary>
        /// Returns a string representation of the circle.
        /// </summary>
        /// <returns>A string with dimensions and area of the circle.</returns>
        public override string ToString()
        {
            return $"{Type} - Radius: {Radius}, Area: {CalculateArea()}";
        }
        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
