﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

using System;

namespace Lab2
{
    /// <summary>
    /// Represents a rectangle shape.
    /// </summary>
    public class Rectangle : Shape
    {
        /// <summary>
        /// Gets or sets the width of the rectangle.
        /// </summary>
        public double Width { get; set; }

        /// <summary>
        /// Gets or sets the height of the rectangle.
        /// </summary>
        public double Height { get; set; }

        /// <summary>
        /// Initializes a new instance of the Rectangle class.
        /// </summary>
        public Rectangle()
        {
            Type = "Rectangle";
        }

        /// <summary>
        /// Calculates the area of the rectangle.
        /// </summary>
        /// <returns>The area of the rectangle.</returns>
        public override double CalculateArea() => Width * Height;

        /// <summary>
        /// Calculates the volume of the rectangle (always 0 as it's 2D).
        /// </summary>
        /// <returns>0 for 2D shapes.</returns>
        public override double CalculateVolume() => 0;

        /// <summary>
        /// Prompts the user to enter the dimensions of the rectangle.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter width: ");
            Width = GetValidDouble();
            Console.Write("Enter height: ");
            Height = GetValidDouble();
        }

        /// <summary>
        /// Returns a string representation of the rectangle.
        /// </summary>
        /// <returns>A string with dimensions and area of the rectangle.</returns>
        public override string ToString()
        {
            return $"{Type} - Width: {Width}, Height: {Height}, Area: {CalculateArea()}";
        }

        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
