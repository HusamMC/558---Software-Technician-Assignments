﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;

namespace Lab2
{
    /// <summary>
    /// Represents a tetrahedron shape.
    /// </summary>
    public class Tetrahedron : Shape
    {
        /// <summary>
        /// Gets or sets the edgelength of the tetrahedron.
        /// </summary>
        public double EdgeLength { get; set; }
        /// <summary>
        /// Initializes a new instance of the tetrahedron class.
        /// </summary>
        public Tetrahedron()
        {
            Type = "Tetrahedron";
        }
        /// <summary>
        /// Calculates the area of the tetrahedron.
        /// </summary>
        public override double CalculateArea() => Math.Sqrt(3) * EdgeLength * EdgeLength;
        /// <summary>
        /// Calculates the volume of the tetrahedron.
        /// </summary>
        public override double CalculateVolume() => (Math.Pow(EdgeLength, 3) / (6 * Math.Sqrt(2)));
        /// <summary>
        /// Prompts the user to enter the dimensions of the tetrahedron.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter edge length: ");
            EdgeLength = GetValidDouble();
        }
        /// <summary>
        /// Returns a string representation of the tetrahedron.
        /// </summary>
        /// <returns>A string with dimensions and area of the tetrahedron.</returns>
        public override string ToString()
        {
            return $"{Type} - Edge Length: {EdgeLength}, Area: {CalculateArea()}, Volume: {CalculateVolume()}";
        }
        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
