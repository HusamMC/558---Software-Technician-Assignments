﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;

namespace Lab2
{
    /// <summary>
    /// Represents a triangle shape.
    /// </summary>
    public class Triangle : Shape
    {
        /// <summary>
        /// Gets or sets the base of the triangle.
        /// </summary>
        public double Base { get; set; }
        /// <summary>
        /// Gets or sets the height of the triangle.
        /// </summary>
        public double Height { get; set; }
        /// <summary>
        /// Initializes a new instance of the triangle class.
        /// </summary>
        public Triangle()
        {
            Type = "Triangle";
        }
        /// <summary>
        /// Calculates the area of the triangle.
        /// </summary>
        public override double CalculateArea() => 0.5 * Base * Height;
        /// <summary>
        /// Calculates the volume of the triangle.
        /// </summary>
        public override double CalculateVolume() => 0; // Not a 3D shape
        /// <summary>
        /// Prompts the user to enter the dimensions of the triangle.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter base: ");
            Base = GetValidDouble();
            Console.Write("Enter height: ");
            Height = GetValidDouble();
        }
        /// <summary>
        /// Returns a string representation of the triangle.
        /// </summary>
        /// <returns>A string with dimensions and area of the triangle.</returns>
        public override string ToString()
        {
            return $"{Type} - Base: {Base}, Height: {Height}, Area: {CalculateArea()}";
        }
        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
