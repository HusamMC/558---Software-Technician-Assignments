﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;
using System.Collections.Generic;

/// <summary>
/// Main program that prompts user input.
/// </summary>
namespace Lab2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Shape> shapes = new List<Shape>();
            bool running = true;

            /// <summary>
            /// Prompts the user to enter a letter for the shape they want to make.
            /// </summary>
            while (running)
            {
                Console.WriteLine("Welcome to Shape Shack");
                Console.WriteLine("===============================================================================");
                Console.WriteLine($"{"A - Rectangle",-20} {"B - Square",-20} {"C - Box",-20} {"D - Cube",-20}");
                Console.WriteLine($"{"E - Ellipse",-20} {"F - Circle",-20} {"G - Cylinder",-20} {"H - Sphere",-20}");
                Console.WriteLine($"{"I - Triangle",-20} {"J - Tetrahedron",-20}");
                Console.WriteLine("0 - List all shapes and close....");
                Console.WriteLine("===============================================================================");
                Console.Write("List your choice: ");
                string choice = Console.ReadLine().ToUpper();

                /// <summary>
                /// Switch statement which calls the createshape method.
                /// </summary>
                switch (choice)
                {
                    case "A":
                        shapes.Add(CreateShape<Rectangle>());
                        break;
                    case "B":
                        shapes.Add(CreateShape<Square>());
                        break;
                    case "C":
                        shapes.Add(CreateShape<Box>());
                        break;
                    case "D":
                        shapes.Add(CreateShape<Cube>());
                        break;
                    case "E":
                        shapes.Add(CreateShape<Ellipse>());
                        break;
                    case "F":
                        shapes.Add(CreateShape<Circle>());
                        break;
                    case "G":
                        shapes.Add(CreateShape<Cylinder>());
                        break;
                    case "H":
                        shapes.Add(CreateShape<Sphere>());
                        break;
                    case "I":
                        shapes.Add(CreateShape<Triangle>());
                        break;
                    case "J":
                        shapes.Add(CreateShape<Tetrahedron>());
                        break;
                    case "0":
                        running = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }

            Console.WriteLine("\nShapes Created:");
            Console.WriteLine("===============================================================");

            /// <summary>
            /// Iterates through a list of shapes and writes their string representations to the console.
            /// </summary>
            /// <param name="shapes">The collection of shapes to be processed.</param>
            foreach (var shape in shapes)
            {
                Console.WriteLine(shape.ToString());
            }
            Console.WriteLine("===============================================================");
        }
        /// <summary>
        /// Creates an instance of a shape of type T, where T is a subclass of Shape.
        /// Initializes the shape by calling its SetData method.
        /// </summary>
        /// <typeparam name="T">The type of shape to create, which must be a subclass of Shape.</typeparam>
        /// <returns>An instance of the shape of type T.</returns>
        private static T CreateShape<T>() where T : Shape, new()
        {
            T shape = new T();
            shape.SetData();
            return shape;
        }
    }
}
