﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;

namespace Lab2
{
    /// <summary>
    /// Represents a square shape.
    /// </summary>
    public class Square : Shape
    {
        /// <summary>
        /// Gets or sets the side length of the square.
        /// </summary>
        public double Side { get; set; }

        /// <summary>
        /// Initializes a new instance of the Square class.
        /// </summary>
        public Square()
        {
            Type = "Square";
        }

        /// <summary>
        /// Calculates the area of the square.
        /// </summary>
        /// <returns>The area of the square.</returns>
        public override double CalculateArea() => Side * Side;

        /// <summary>
        /// Calculates the volume of the square (always 0 as it's 2D).
        /// </summary>
        /// <returns>0 for 2D shapes.</returns>
        public override double CalculateVolume() => 0;

        /// <summary>
        /// Prompts the user to enter the dimensions of the square.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter side length: ");
            Side = GetValidDouble();
        }

        /// <summary>
        /// Returns a string representation of the square.
        /// </summary>
        /// <returns>A string with the side length and area of the square.</returns>
        public override string ToString()
        {
            return $"{Type} - Side: {Side}, Area: {CalculateArea()}";
        }
        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
