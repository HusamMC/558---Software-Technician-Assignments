﻿///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;

namespace Lab2
{
    /// <summary>
    /// Represents a sphere shape.
    /// </summary>
    public class Sphere : Shape
    {
        /// <summary>
        /// Gets or sets the radius of the sphere.
        /// </summary>
        public double Radius { get; set; }
        /// <summary>
        /// Initializes a new instance of the sphere class.
        /// </summary>
        public Sphere()
        {
            Type = "Sphere";
        }
        /// <summary>
        /// Calculates the area of the sphere.
        /// </summary>
        public override double CalculateArea() => 4 * PI * Radius * Radius;
        /// <summary>
        /// Calculates the volume of the sphere.
        /// </summary>
        public override double CalculateVolume() => (4.0 / 3.0) * PI * Radius * Radius * Radius;
        /// <summary>
        /// Prompts the user to enter the dimensions of the sphere.
        /// </summary>
        public override void SetData()
        {
            Console.Write("Enter radius: ");
            Radius = GetValidDouble();
        }
        /// <summary>
        /// Returns a string representation of the sphere.
        /// </summary>
        /// <returns>A string with dimensions and area of the sphere.</returns>
        public override string ToString()
        {
            return $"{Type} - Radius: {Radius}, Area: {CalculateArea()}, Volume: {CalculateVolume()}";
        }
        /// <summary>
        /// Gets a valid positive double input from the user.
        /// </summary>
        /// <returns>A valid positive double value.</returns>
        private double GetValidDouble()
        {
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value > 0)
                {
                    return value;
                }
                Console.Write("Invalid input. Please enter a positive number: ");
            }
        }
    }
}
