﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

namespace LabAssignment3B
{
    /// <summary>
    /// Represents the main form for the hairdresser and service selection application.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// A dictionary to store hairdresser names and their respective rates.
        /// </summary>
        private Dictionary<string, decimal> hairdresserRates;

        /// <summary>
        /// A dictionary to store service names and their respective rates.
        /// </summary>
        private Dictionary<string, decimal> serviceRates;

        /// <summary>
        /// Indicates whether the hairdresser has been added to the charge list.
        /// </summary>
        private bool isFirstServiceAdded = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            InitializeItems();
        }

        /// <summary>
        /// Event handler for hairdresser selection changes.
        /// </summary>
        private void hairDresserBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Event handler for any actions when a hairdresser is selected.
        }

        /// <summary>
        /// Event handler for the exit button click event. Closes the form.
        /// </summary>
        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Event handler for the reset button click event. Resets the form to its initial state.
        /// </summary>
        private void resetButton_Click(object sender, EventArgs e)
        {
            // Reset selections and clear lists
            hairDresserBox.SelectedIndex = 0;
            hairDresserBox.Enabled = true;

            chargedItemsListBox.Items.Clear();
            priceListBox.Items.Clear();
            priceDisplay.Text = "Total: $0.00";

            // Reset flags and button states
            isFirstServiceAdded = false;
            addButton.Enabled = false;
            calculateButton.Enabled = false;

            // Set focus back to hairdresser ComboBox
            hairDresserBox.Focus();
        }

        /// <summary>
        /// Event handler for the add button click event. Adds the selected hairdresser and services to the charged items list.
        /// </summary>
        private void addButton_Click(object sender, EventArgs e)
        {
            // Add hairdresser only once
            if (!isFirstServiceAdded)
            {
                string selectedHairdresser = hairDresserBox.SelectedItem.ToString();
                chargedItemsListBox.Items.Add(selectedHairdresser);
                priceListBox.Items.Add($"${hairdresserRates[selectedHairdresser]:F2}");

                hairDresserBox.Enabled = false;
                isFirstServiceAdded = true;
                calculateButton.Enabled = true;
            }

            // Add selected services
            foreach (var selectedService in serviceListBox.SelectedItems)
            {
                string service = selectedService.ToString();
                chargedItemsListBox.Items.Add(service);
                priceListBox.Items.Add($"${serviceRates[service]:F2}");
            }
        }

        /// <summary>
        /// Initializes the hairdresser and service lists and populates the selection controls.
        /// </summary>
        public void InitializeItems()
        {
            // Hairdresser rates
            hairdresserRates = new Dictionary<string, decimal>
            {
                { "Jane Samley", 30m },
                { "Pat Johnson", 45m },
                { "Ron Chambers", 40m },
                { "Sue Pallon", 50m },
                { "Laura Renkins", 55m }
            };

            // Service rates
            serviceRates = new Dictionary<string, decimal>
            {
                { "Cut", 30m },
                { "Wash, blow-dry, and style", 20m },
                { "Colour", 40m },
                { "Highlights", 50m },
                { "Extension", 200m },
                { "Up-do", 60m }
            };

            // Populate ComboBox and ListBox
            hairDresserBox.Items.AddRange(hairdresserRates.Keys.ToArray());
            serviceListBox.Items.AddRange(serviceRates.Keys.ToArray());

            // Set default ComboBox selection and initial control states
            hairDresserBox.SelectedIndex = 0;
            addButton.Enabled = false;
            calculateButton.Enabled = false;
        }

        /// <summary>
        /// Event handler for service selection changes in the ListBox. Enables the add button if at least one service is selected.
        /// </summary>
        private void serviceListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Enable Add Service button when at least one service is selected
            addButton.Enabled = serviceListBox.SelectedItems.Count > 0;
        }

        /// <summary>
        /// Event handler for the charged items list selection changes.
        /// </summary>
        private void chargedItemsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Placeholder for any actions when charged items are selected.
        }

        /// <summary>
        /// Event handler for the calculate button click event. Calculates and displays the total price of selected items.
        /// </summary>
        private void calculateButton_Click(object sender, EventArgs e)
        {
            decimal totalPrice = 0;

            foreach (var item in priceListBox.Items)
            {
                // Parse price values from priceListBox
                if (decimal.TryParse(item.ToString().Trim('$'), out decimal price))
                {
                    totalPrice += price;
                }
            }

            // Display total price in currency format
            priceDisplay.Text = $"Total: ${totalPrice:F2}";
        }
    }
}
