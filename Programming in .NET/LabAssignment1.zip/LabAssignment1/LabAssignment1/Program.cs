﻿//I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAssignment1
{
    internal class Program
    {
        //Delcaring an Array of Employee using the employee class.
        //Implementing the selection sort algorithm.
        //prompting the users for a selection from 1-6.

        static void Main(string[] args)
        {
            Employee[] employees = new Employee[100];
            int count = ReadEmployees(employees);

            if (count > 0)
            {
                bool exit = false;
                while (!exit)
                {
                    Console.WriteLine("=======================================");
                    Console.WriteLine("1. Sort by Employee Name (ascending)");
                    Console.WriteLine("2. Sort by Employee Number (ascending)");
                    Console.WriteLine("3. Sort by Employee Pay Rate (descending)");
                    Console.WriteLine("4. Sort by Employee Hours (descending)");
                    Console.WriteLine("5. Sort by Employee Gross Pay (descending)");
                    Console.WriteLine("6. Exit");
                    

                    string option = Console.ReadLine();
                    Console.Clear();

                    switch (option)
                    {
                        case "1":
                            selectionSort(employees, count, (a, b) => string.Compare(a.GetName(), b.GetName()) < 0);
                            DisplayEmployees(employees, count);
                            break;
                        case "2":
                            selectionSort(employees, count, (a, b) => a.GetNumber() < b.GetNumber());
                            DisplayEmployees(employees, count);
                            break;
                        case "3":
                            selectionSort(employees, count, (a, b) => a.GetRate() > b.GetRate());
                            DisplayEmployees(employees, count);
                            break;
                        case "4":
                            selectionSort(employees, count, (a, b) => a.GetHours() > b.GetHours());
                            DisplayEmployees(employees, count);
                            break;
                        case "5":
                            selectionSort(employees, count, (a, b) => a.GetGross() > b.GetGross());
                            DisplayEmployees(employees, count);
                            break;
                        case "6":
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("\nInvalid choice.");
                            break;
                    }
                }
            }
            else
            {
                Console.WriteLine("No employees found or file does not exist.");
            }
        }

        //Reading and displaying the employees.txt file.
        //As well as error checking if file exists.
        static int ReadEmployees(Employee[] employees)
        {
            string fileName = "employees.txt";
            FileInfo fileInfo = new FileInfo(fileName);
            int count = 0;

            if (fileInfo.Exists)
            {
                using (FileStream file = new FileStream(fileName, FileMode.Open, FileAccess.Read))
                using (StreamReader data = new StreamReader(file))
                {
                    string line;
                    while ((line = data.ReadLine()) != null && count < employees.Length)
                    {
                        string[] exploded = line.Split(',');
                        employees[count++] = new Employee(exploded[0], Convert.ToInt32(exploded[1]), Convert.ToDecimal(exploded[2]), Convert.ToDouble(exploded[3]));
                    }
                }
            }
            else
            {
                Console.WriteLine("File does not exist. Please make sure the file is in the correct location.");
            }

            return count;
        }

        //https://www.crio.do/blog/top-10-sorting-algorithms/
        //Insertioning sorting algorithm used to sort employees.
        //sorting method found on crio and changed to fit the structure of this code


        //Declaring a temporary value to move values around within the loop

        static void swap(Employee[] empArray, int i, int j)
        {
            Employee temp = empArray[i];
            empArray[i] = empArray[j];
            empArray[j] = temp;
        }


        //Iterates through each element of the array
        //Sorts the employee objects by comparing the objects.
       
        static void selectionSort(Employee[] empArray, int count, Func<Employee, Employee, bool> compare)
        {
            for (int i = 0; i < count - 1; i++)
            {
                int targetIndex = i;
                for (int j = i + 1; j < count; j++)
                {
                    if (compare(empArray[j], empArray[targetIndex]))
                    {
                        targetIndex = j;
                    }
                }
                swap(empArray, i, targetIndex);
            }
        }

        //Displaying the sorted information of the array.

        static void DisplayEmployees(Employee[] employees, int count)
        {
            Console.WriteLine($"{"\nName",-15} {"Number",12} {"Rate",8} {"Hours",12} {"Gross Pay",16}");
            Console.WriteLine(new string('-', 69));
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine(employees[i].ToString());
            }
        }
    }
}
