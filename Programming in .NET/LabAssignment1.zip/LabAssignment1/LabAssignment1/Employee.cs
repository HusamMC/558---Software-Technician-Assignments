﻿//I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Employee Class Which contains the name,
//rate, hours, number(id) and gross salery.

namespace LabAssignment1
{
    internal class Employee
    {
        private String name;
        private int number;
        private decimal rate;
        private double hours;
        private decimal gross;
        
        //Main Constructor contains name, number, rate and hours.
        public Employee(String name, int number, decimal rate, double hours) 
        {
            this.name = name;
            this.number = number;
            this.rate = rate;
            this.hours = hours;
            this.gross = GetGross();
           
        }


        //Calculating the gross rate
        public decimal GetGross() {
            gross = Convert.ToDecimal(hours) * rate;

            if (hours > 40)
            {
                decimal overtimeHours = Convert.ToDecimal(hours - 40);
                decimal overtimeRate = rate * 1.5m;
                gross += overtimeHours * overtimeRate;
            }
            return gross; }

        //Getters for hours, name, number and rate.
        public double GetHours() { return hours; }
        public decimal GetRate() { return rate; }
        public string GetName() { return name; }
        public int GetNumber() { return number; }


        //Printing and positioning the information using a tostring.
        override
        public String ToString()
        { 
            return $"{name,-15} {number,12} {rate,8:C} {hours,12} {gross,16:C}";
        }

        //Setters for hours, name, number and rate.
        public double SetHours() { return hours; }
        public string SetName() { return name; }
        public int SetNumber() { return number; }
        public decimal SetRate() { return rate; }






    }
}
