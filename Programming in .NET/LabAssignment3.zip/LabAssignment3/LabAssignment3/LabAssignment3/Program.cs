﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

namespace LabAssignment3
{
    /// <summary>
    /// The main program class, responsible for initializing the media collection and handling user interaction.
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Collection to hold media objects, with a maximum capacity of 10,000 items.
        /// </summary>
        public static Media[] mediaCollection = new Media[10000];

        /// <summary>
        /// The main entry point of the program, displays the menu and handles user choices.
        /// </summary>
        /// <param name="args">Command-line arguments (not used).</param>
        static void Main(string[] args)
        {
            // Call ReadData to populate mediaCollection from the file
            ReadData();

            // Ensure that the media collection has been populated
            if (mediaCollection.Length > 0 && mediaCollection[0] != null)
            {
                bool exit = false;
                while (!exit)
                {
                    Console.WriteLine("Media Shop");
                    Console.WriteLine("1. List All Books");
                    Console.WriteLine("2. List All Movies");
                    Console.WriteLine("3. List All Songs");
                    Console.WriteLine("4. List All Media");
                    Console.WriteLine("5. Search All Media by Title");
                    Console.WriteLine("6. Exit Program");

                    Console.Write("Please enter your choice (1-6): ");
                    string choice = Console.ReadLine();
                    Console.Clear();

                    switch (choice)
                    {
                        case "1":
                            ListBooks(mediaCollection);
                            break;
                        case "2":
                            ListMovies(mediaCollection);
                            break;
                        case "3":
                            ListSongs(mediaCollection);
                            break;
                        case "4":
                            ListAllMedia(mediaCollection);
                            break;
                        case "5":
                            Console.Write("Enter a title to search: ");
                            string keyword = Console.ReadLine();
                            SearchMediaByTitle(mediaCollection, keyword);
                            break;
                        case "6":
                            Console.WriteLine("Goodbye!");
                            exit = true;
                            break;
                        default:
                            Console.WriteLine("Invalid choice. Please enter a number between 1 and 6.\n");
                            break;
                    }
                }
            }
            else
            {
                Console.WriteLine("No media found. Please ensure the data file exists and has valid data.");
            }
        }

        /// <summary>
        /// Reads data from a file to populate the media collection with media items like books, movies, and songs.
        /// </summary>
        static void ReadData()
        {
            string filename = "Data.txt";

            try
            {
                if (!File.Exists(filename))
                {
                    Console.WriteLine("Data file not found. Please ensure it is in the correct location.");
                    return;
                }

                using (StreamReader data = new StreamReader(filename))
                {
                    int count = 0;
                    string line;
                    while ((line = data.ReadLine()) != null && count < mediaCollection.Length)
                    {
                        if (line.Trim() == "-----") continue;  // Skip separator lines

                        string[] parts = line.Split('|');
                        if (parts.Length < 4)  // Ensure we have enough parts for Book, Movie, or Song
                        {
                            Console.WriteLine($"Skipping malformed line: {line}");
                            continue;
                        }

                        // Validate year conversion to prevent exceptions
                        if (!int.TryParse(parts[2], out int year))
                        {
                            Console.WriteLine($"Invalid year format in line: {line}");
                            continue;
                        }

                        string mediaSummary = "";

                        switch (parts[0].ToUpper())  // Use ToUpper to handle case-insensitive media types
                        {
                            case "BOOK":
                                while ((line = data.ReadLine()) != null && line.Trim() != "-----")
                                {
                                    mediaSummary += line.Trim();
                                }
                                mediaCollection[count++] = new Book(parts[1], year, parts[3], mediaSummary);
                                break;
                            case "MOVIE":
                                while ((line = data.ReadLine()) != null && line.Trim() != "-----")
                                {
                                    mediaSummary += line.Trim();
                                }
                                mediaCollection[count++] = new Movie(parts[1], year, parts[3], mediaSummary);
                                break;
                            case "SONG":
                                mediaCollection[count++] = new Song(parts[1], year, parts[3], parts[4]);
                                break;
                            default:
                                Console.WriteLine($"Unknown media type: {parts[0]} in line: {line}");
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while reading the file: {ex.Message}");
            }
        }

        /// <summary>
        /// Lists all books in the media collection.
        /// </summary>
        /// <param name="mediaCollection">The collection of media items.</param>
        static void ListBooks(Media[] mediaCollection)
        {
            Console.WriteLine("Listing all books:");
            foreach (var media in mediaCollection)
            {
                if (media is Book book)
                {
                    Console.WriteLine($"Title: {book.Title}, Author: {book.Author}");
                }
            }
        }

        /// <summary>
        /// Lists all movies in the media collection.
        /// </summary>
        /// <param name="mediaCollection">The collection of media items.</param>
        static void ListMovies(Media[] mediaCollection)
        {
            Console.WriteLine("Listing all movies:");
            foreach (var media in mediaCollection)
            {
                if (media is Movie movie)
                {
                    Console.WriteLine($"Title: {movie.Title}, Director: {movie.Director}");
                }
            }
        }

        /// <summary>
        /// Lists all songs in the media collection.
        /// </summary>
        /// <param name="mediaCollection">The collection of media items.</param>
        static void ListSongs(Media[] mediaCollection)
        {
            Console.WriteLine("Listing all songs:");
            foreach (var media in mediaCollection)
            {
                if (media is Song song)
                {
                    Console.WriteLine($"Title: {song.Title}, Album: {song.Album}, Artist: {song.Artist}");
                }
            }
        }

        /// <summary>
        /// Lists all media items in the media collection.
        /// </summary>
        /// <param name="mediaCollection">The collection of media items.</param>
        static void ListAllMedia(Media[] mediaCollection)
        {
            Console.WriteLine("Listing all media:");
            foreach (var media in mediaCollection)
            {
                if (media != null)
                {
                    Console.WriteLine($"Title: {media.Title}");
                }
            }
        }

        /// <summary>
        /// Searches the media collection by title keyword and displays matching items.
        /// </summary>
        /// <param name="mediaCollection">The collection of media items.</param>
        /// <param name="keyword">The title keyword to search for.</param>
        static void SearchMediaByTitle(Media[] mediaCollection, string keyword)
        {
            Console.WriteLine($"Search results for '{keyword}':");
            foreach (var media in mediaCollection)
            {
                if (media != null && media.Search(keyword))
                {
                    Console.WriteLine($"Title: {media.Title}");
                    if (media is IEncryptable encryptableMedia)
                    {
                        Console.WriteLine($"Summary: {encryptableMedia.Decrypt()}");
                    }
                }
            }
        }
    }
}
