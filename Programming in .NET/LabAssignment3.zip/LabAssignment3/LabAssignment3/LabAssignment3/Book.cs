﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

namespace LabAssignment3
{
    /// <summary>
    /// Represents a book, which is a type of media, inheriting from the Media class and implementing the IEncryptable interface.
    /// </summary>
    public class Book : Media, IEncryptable
    {
        /// <summary>
        /// Gets the author of the book.
        /// </summary>
        public string Author { get; private set; }

        /// <summary>
        /// Gets or sets the summary of the book, which is an encrypted field.
        /// </summary>
        public string Summary { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Book"/> class.
        /// </summary>
        /// <param name="title">The title of the book.</param>
        /// <param name="year">The publication year of the book.</param>
        /// <param name="author">The author of the book.</param>
        /// <param name="summary">The summary or description of the book, which will be encrypted.</param>
        public Book(string title, int year, string author, string summary) : base(title, year)
        {
            Author = author;
            Summary = summary;
        }

        /// <summary>
        /// Encrypts the book's summary using the ROT13 cipher.
        /// </summary>
        /// <returns>The encrypted summary.</returns>
        public string Encrypt()
        {
            return Rot13(Summary);
        }

        /// <summary>
        /// Decrypts the book's summary using the ROT13 cipher (reverses the encryption).
        /// </summary>
        /// <returns>The decrypted summary.</returns>
        public string Decrypt()
        {
            return Rot13(Summary);
        }

        /// <summary>
        /// Applies the ROT13 cipher to a given input string. ROT13 shifts each letter by 13 places in the alphabet.
        /// </summary>
        /// <param name="input">The string to be encrypted or decrypted.</param>
        /// <returns>The result of applying the ROT13 cipher on the input.</returns>
        private string Rot13(string input)
        {
            return new string(input.Select(c => char.IsLetter(c)
                ? (char)(((c & 223) - 'A' + 13) % 26 + 'A' + (c & 32))
                : c).ToArray());
        }
    }
}
