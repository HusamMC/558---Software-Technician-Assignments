﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

namespace LabAssignment3
{
    /// <summary>
    /// Represents a song which is a type of media, inheriting from the Media class.
    /// </summary>
    public class Song : Media
    {
        /// <summary>
        /// Gets the name of the album in which the song is featured.
        /// </summary>
        public string Album { get; private set; }

        /// <summary>
        /// Gets the artist who performed the song.
        /// </summary>
        public string Artist { get; private set; }

        /// <summary>
        /// Initializes a new instance of the song class.
        /// </summary>
        /// <param name="title">The title of the song.</param>
        /// <param name="year">The release year of the song.</param>
        /// <param name="album">The album that includes the song.</param>
        /// <param name="artist">The artist who performed the song.</param>
        public Song(string title, int year, string album, string artist) : base(title, year)
        {
            Album = album;
            Artist = artist;
        }
    }
}
