﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

namespace LabAssignment3
{
    /// <summary>
    /// Represents a movie, which is a type of media, inheriting from the Media class and implementing the IEncryptable interface.
    /// </summary>
    public class Movie : Media, IEncryptable
    {
        /// <summary>
        /// Gets the director of the movie.
        /// </summary>
        public string Director { get; private set; }

        /// <summary>
        /// Gets or sets the summary of the movie, which is an encrypted field.
        /// </summary>
        public string Summary { get; private set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Movie"/> class.
        /// </summary>
        /// <param name="title">The title of the movie.</param>
        /// <param name="year">The release year of the movie.</param>
        /// <param name="director">The director of the movie.</param>
        /// <param name="summary">The summary or description of the movie, which will be encrypted.</param>
        public Movie(string title, int year, string director, string summary) : base(title, year)
        {
            Director = director;
            Summary = summary;
        }

        /// <summary>
        /// Encrypts the movie's summary using the ROT13 cipher.
        /// </summary>
        /// <returns>The encrypted summary.</returns>
        public string Encrypt()
        {
            return Rot13(Summary);
        }

        /// <summary>
        /// Decrypts the movie's summary using the ROT13 cipher (reverses the encryption).
        /// </summary>
        /// <returns>The decrypted summary.</returns>
        public string Decrypt()
        {
            return Rot13(Summary);
        }

        /// <summary>
        /// Applies the ROT13 cipher to a given input string. ROT13 shifts each letter by 13 places in the alphabet.
        /// </summary>
        /// <param name="input">The string to be encrypted or decrypted.</param>
        /// <returns>The result of applying the ROT13 cipher on the input.</returns>
        private string Rot13(string input)
        {
            return new string(input.Select(c => char.IsLetter(c)
                ? (char)(((c & 223) - 'A' + 13) % 26 + 'A' + (c & 32))
                : c).ToArray());
        }
    }
}
