﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
///I, Husam Abdelhalim, 000104532 certify that this material is my original work.  No other person's work has been used without due acknowledgement.

namespace LabAssignment3
{
    /// <summary>
    /// Represents a shop that extends the Media class, providing basic properties like title and year.
    /// </summary>
    internal class Shop : Media
    {
        /// <summary>
        /// The type of media or product available in the shop.
        /// </summary>
        private string type;

        /// <summary>
        /// The title associated with the shop or media item.
        /// </summary>
        private string title;

        /// <summary>
        /// The year associated with the shop or media item.
        /// </summary>
        private int year;

        /// <summary>
        /// The author or creator of the media item.
        /// </summary>
        private string author;

        /// <summary>
        /// Initializes a new instance of the <see cref="Shop"/> class with a specified title and year.
        /// </summary>
        /// <param name="title">The title associated with the shop or media item.</param>
        /// <param name="year">The year associated with the shop or media item.</param>
        public Shop(string title, int year) : base(title, year)
        {
            this.title = title;
            this.year = year;
        }
    }
}
