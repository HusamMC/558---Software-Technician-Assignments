//Husam Abdelhalim - 000104532

//declaring a 3x3 2D image array
var imageArray = [
    ["./images/image1.jpg", "./images/image2.jpg", "./images/image3.jpg"],
    ["./images/image4.jpg", "./images/image5.jpg", "./images/image6.jpg"],
    ["./images/image7.jpg", "./images/image8.jpg", "./images/image9.jpg"]
];

//instance vars
let counter = 0; 
let timerInterval; 
let defaultTime = 10000;
let userSetTime = 0;

//function to load initial images
function loadInitialImages() {
    document.getElementById("images1").src = imageArray[randomNumber()][randomNumber()];
    document.getElementById("images2").src = imageArray[randomNumber()][randomNumber()];
    document.getElementById("images3").src = imageArray[randomNumber()][randomNumber()];   
    counter = 0; 
    updateCounter(); 
}

//Function to update one image when clicked
function oneImageRandom(event) { 
    const oneImage = event.currentTarget.id;
    document.getElementById(oneImage).src = imageArray[randomNumber()][randomNumber()];
    do_animation(event); 
    counter++;
    resetTimer();
    updateCounter();
}

//Animation function
function do_animation(event) { 
    target = event.currentTarget;
    target.classList.remove('rotate-animation');
    setTimeout(() => { target.classList.add('rotate-animation'); }, 0);
}

//Function to update the counter
function updateCounter() {
    document.getElementById("counter").textContent = counter;   
}


//Verifies user input and adjusts the timer accordingly
function userInputTimer(){ 
    let input = document.getElementById("input_timer").value;
    input = parseInt(input);
    if (isNaN(input)){
        alert("Not a number. Please enter an integer number.");
    } else {
        if (input >= 500 && input <= 10000){
            userSetTime=input; 
            resetTimer();
            document.getElementById("timer").textContent = input;
            return userSetTime;
        }
    }
}

//Updates the time and displays the corresponding color scheme
function updateTimer() {
    defaultTime -= 100;
    const output_timer = document.getElementById("timer");
    output_timer.textContent = (defaultTime / 1000).toFixed(1);
    if (defaultTime <= 0) {
        clearInterval(timerInterval); 
        changeImages();
        defaultTime = userSetTime != 0 ? userSetTime : 9000;
        timerInterval = setInterval(updateTimer, 100); 
    } else if (defaultTime <= 0.333 * (userSetTime != 0 ? userSetTime : 10000)) {
        document.getElementById("timer").classList.remove("greentimer", "yellowtimer");
        document.getElementById("timer").classList.add("redtimer");
    } else if (defaultTime <= 0.666 * (userSetTime != 0 ? userSetTime : 10000)) {
        document.getElementById("timer").classList.remove("greentimer", "redtimer");
        document.getElementById("timer").classList.add("yellowtimer");
    } else {
        document.getElementById("timer").classList.remove("yellowtimer", "redtimer");
        document.getElementById("timer").classList.add("greentimer");
    } 
}


//starts the intial timer
function startTimer() {
    timerInterval = setInterval(updateTimer, 100); 
}

//resets the Timer
function resetTimer() {
    clearInterval(timerInterval);
    defaultTime = userSetTime || 10000;
    document.getElementById("timer").textContent = defaultTime / 1000;
    startTimer(); 
}

//Function that changes all three images
function changeImages() {
    document.getElementById("images1").src = imageArray[randomNumber()][randomNumber()];
    document.getElementById("images2").src = imageArray[randomNumber()][randomNumber()];
    document.getElementById("images3").src = imageArray[randomNumber()][randomNumber()];
    counter += 3; 
    updateCounter(); 
}

//onload to start the timer and load the images
window.onload = function () {
    loadInitialImages(); 
    startTimer(); 
};

function randomNumber() { //Generates a random number between 0 and 3
    let randomInteger = Math.floor(Math.random() * 3);
    return randomInteger;
}
