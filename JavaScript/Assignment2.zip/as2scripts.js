//Assignment 2

// Group 1 - Choice 1 question - Get a number.
function group1_choice1() {
    let userInput = document.getElementById("q1c1_input");
    let userOutput = document.getElementById("q1c1_output");

    let inputValue = userInput.value;
    let outputText = " ";

    if (!isNaN(inputValue)) {
        let value = parseFloat(inputValue);
        
        if (value === 0 || (value >= 13 && value <=17)) {
            outputText = "In range";
        } else {
            outputText = "Out of range";
        }
    } else {
        outputText = "Not a number";
    }
    userOutput.value = outputText;
};
group1_choice1()

//Group 1 - Choice 3 question - Get a shape.
function group1_choice3 () {
    let userInput = document.getElementById("q1c3_input");
    let userOutput = document.getElementById("q1c3_output");

    let side = parseFloat(userInput.value);
    let outputText = " ";
    
    if (isNaN(side) || side <= 0) {
        outputText = "Can't calculate";
    } else {
        let perimeter = 4 * side;
        let area = side * side;
        outputText = "Perimeter: " + perimeter + ", Area: " + area;        
    }
    userOutput.value = outputText;

};
group1_choice3()

//Group 2 - Choice 1 question - Buy a vowel.
function checkVowel() {
    let userInput = document.getElementById("q2c1_input");
    let userOutput = document.getElementById("q2c1_output");

    let inputValue = userInput.value;
    let outputText = " ";

        
    while (true) {
        if(inputValue == "a" || inputValue == "e" || inputValue == "i" || inputValue == "o" || inputValue == "u" ){
            outputText="A Vowel";
            break;

        } else if (inputValue=="y"){
            outputText="Sometimes";
            break;
        } else{
            outputText="Not a Vowel";
            break;
        }
    }
    userOutput.textContent = outputText;
    
};
checkVowel()

//Group 2 - Choice 3 question - Factorial value.
function factorialValue() {
    let userInput = document.getElementById("q2c2_input");
    let userOutput = document.getElementById("q2c2_output");

    let inputValue = userInput.value;
    let outputText = "";
    let value = parseFloat(inputValue);
    let result = 1;
    

    if(isNaN(value) || value < 0) {
       
        outputText = "Cannot compute factorial number";

    } else {
        for (let i = value; i >= 1; i--) {
            result *= i;
        }

        outputText = result.toString();
    }
    userOutput.textContent = outputText;

};
factorialValue()

//Group 3 - Choice 2 question - Short equation.
function binaryEquation() {
    let userInput = document.getElementById("q3c1_input");
    let userOutput = document.getElementById("q3c1_output");

    let inputValue = userInput.value;
    let outputText = "";
    let outputValue = 0;
    let check = true;

    if (inputValue.length >= 10 && inputValue.length <= 20) {

        for (let i = 0; i < inputValue.length; i++) {
            if (inputValue[i] !== '0' && inputValue[i] !== '1') {
                check = false;
                break;
            }
        }   
    } else {
        check = false;
    }
    if (check) {
        outputValue = parseInt(inputValue, 2);
        outputText = outputValue.toString();
    } else {
        outputText = "Invalid number";
    }

    userOutput.textContent = outputText;
    
};
binaryEquation()


