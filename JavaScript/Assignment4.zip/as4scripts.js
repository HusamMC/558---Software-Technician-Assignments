//Husam Abdelhalim - 000104532
//Variables
const boardsizeX = 800;
const boardsizeY = 500;
const svgNS = "http://www.w3.org/2000/svg"; 
let myScore = 0;
let intervalId = null; 
let gamerunning = false;

//Function to create moving blocks
function makeMovingBlock() {
    let block = document.createElementNS(svgNS, "rect");
    block.setAttribute("x", boardsizeX); 
    block.setAttribute("y", Math.random() * (boardsizeY - 50)); 
    block.setAttribute("width", "50");
    block.setAttribute("height", "50");
    block.setAttribute("fill", "black");
    block.classList.add('moving-block');

    //Event listener to update and award score per click
    block.addEventListener("click", function() {
      
        this.parentNode.removeChild(this);
        myScore += 50;
        updateScore();
    });

    return block;
}

//Function to update score display
function updateScore() {
    document.getElementById("scoreValue").textContent = myScore;
}


//Function to move blocks towards the player
function moveBlocks() {
    let blocks = document.querySelectorAll('.moving-block');
    blocks.forEach(block => {
        let currentX = parseFloat(block.getAttribute('x'));
        if (currentX > -50) {
            block.setAttribute('x', currentX - 1); 
        } else {
            block.parentNode.removeChild(block); 
        }
    });
    requestAnimationFrame(moveBlocks);
}

//Event listener to begingame and call upon other functions
document.addEventListener("DOMContentLoaded", function() {
    let intervalId = null; 

    function beginGame() {
        
        clearBoard();

        myScore = 0;
        updateScore(); 

        if (intervalId !== null) {
            clearInterval(intervalId);
            gamerunning = true;
        }


        let svg = document.getElementById("gamebox");

        intervalId = setInterval(function() {
            let block = makeMovingBlock();
            svg.appendChild(block);
        }, 1000); 

        requestAnimationFrame(moveBlocks);
    }

    //Function to reset the game when the reset button is clicked
    function resetGame() {
        
        clearBoard();

        myScore = 0;
        updateScore();

        if (intervalId !== null) {
            clearInterval(intervalId);
            gamerunning = false;
        }
        
    }

    //Event listener for begin game button
    document.getElementById("start").addEventListener("click", beginGame);

    //Event listener for reset button
    document.getElementById("reset").addEventListener("click", resetGame);



    //Function to clear the board
    function clearBoard() {
        let svg = document.getElementById("gamebox");
        svg.innerHTML = ''; 
    }

});
