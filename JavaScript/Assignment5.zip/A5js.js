//Husam Abdelhalim - 000104532
//April 8th, 2024
window.addEventListener("load", function() {
    document.getElementById("First").addEventListener("click", OnFirstClick);
    document.getElementById("Second").addEventListener("click", OnSecondClick);
    document.getElementById("Third").addEventListener("click", OnThirdClick);
});

//Function for AJAX request to post my student number
function OnFirstClick() {
    let url = "https://csunix.mohawkcollege.ca/~adams/10259/a6_responder.php";

    fetch(url, { credentials: 'include' })
        .then(response => response.text())
        .then(data => {
            let target = document.getElementById("target");
            target.innerHTML = `<h1 style="text-align: center;">${data} - Student #000104532</h1>`;
        })
        .catch(error => {
            console.error("Error fetching data:", error);
        });
}

//Function for AJAX request to post images
function OnSecondClick() {
    let choice = document.getElementById("input").value;
    let url = `https://csunix.mohawkcollege.ca/~adams/10259/a6_responder.php?choice=${choice}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            //Clears Images when typing in a different input.
            document.getElementById("mario").innerHTML = "";
            document.getElementById("starwars").innerHTML = "";

            let flexContainer = document.getElementById(choice);
            if (flexContainer) {
                let flexBasis = `${100 / data.length}%`; 

                data.forEach(item => {
                    let flexItem = document.createElement("div");
                    flexItem.className = "flex-item";
                    flexItem.style.flexBasis = flexBasis;

                    flexItem.innerHTML = `
                        <h2>${item.series}</h2>
                        <img class="image" src="${item.url}" alt="${item.name}">
                        <p>${item.name}</p>
                    `;
                    flexContainer.appendChild(flexItem);
                });

                //Adds the copyright notice below the image
                let copyrightText = "";
                if (choice == "mario") {
                    copyrightText =
                        "Game trademarks and copyrights are properties of their respective owners. Nintendo properties are trademarks of Nintendo. © 2019 Nintendo.";
                } else if (choice == "starwars") {
                    copyrightText =
                        "Star Wars © & TM 2022 Lucasfilm Ltd. All rights reserved. Visual material © 2022 Electronic Arts Inc.";
                }

                let copyrightNotice = document.createElement("p");
                copyrightNotice.textContent = copyrightText;
                copyrightNotice.className = "copyright";

                flexContainer.appendChild(copyrightNotice);
            }
        })
        .catch(error => {
            console.error("Error fetching data:", error);
        });
}

//Function for AJAX request to post elements
function OnThirdClick() {
    let choice = document.getElementById("input").value;
    let url = "https://csunix.mohawkcollege.ca/~adams/10259/a6_responder.php?choice=" + choice;
    let params = { choice: choice };

    fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params)
    })
    .then(response => response.json())
    .then(data => {
        
        let tableHTML = '<table class="table table-light"><thead><tr class="table-dark"><th>Series</th><th>Name</th><th>Link</th></tr></thead><tbody>';
        
        data.forEach(item => {
            tableHTML += `<tr><td>${item.series}</td><td>${item.name}</td><td><a href="${item.url}">Link</a></td></tr>`;
        });

        tableHTML += "</tbody></table>";
        
        let tableContainer = document.getElementById("table-container");
        tableContainer.innerHTML = tableHTML;

        //Adds the copyright notice below the table
        let copyrightNotice = document.createElement("p");
        let copyrightText = "";
        if (choice == "mario") {
            copyrightText = "Game trademarks and copyrights are properties of their respective owners. Nintendo properties are trademarks of Nintendo. © 2019 Nintendo.";
        } else if (choice == "starwars") {
            copyrightText = "Star Wars © & TM 2022 Lucasfilm Ltd. All rights reserved. Visual material © 2022 Electronic Arts Inc.";
        }
        copyrightNotice.textContent = copyrightText;
        copyrightNotice.className = "copyright";
        

        tableContainer.appendChild(copyrightNotice);

    })
    .catch(error => {
        console.error("Error fetching data:", error);
    });

    //Disable the input field after clicking the third button
    document.getElementById("input").disabled = true;
}

