

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import javafx.scene.paint.Color;
import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

import static java.awt.Color.*;
import static javafx.application.Application.launch;

/**
 * Use this template to create drawings in FX. Change the name of the class and
 * put your own name as author below. Change the size of the canvas and the
 * window title where marked and add your drawing code where marked.
 * This stage is used to display cirles and rectangles
 * in the form of the arkanoid game created
 * on Jan 21, 2020
 *
 * @author Husam Abdelhalim, 000104532
 */
public class A1 extends Application {

    /**
     * Start method (use this instead of main).
     *
     *
     *
     * @param stage The FX stage to draw on
     * @throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {
        Group root = new Group();
        Scene scene = new Scene(root, Color.BEIGE);
        Canvas canvas = new Canvas(700, 700); // Set canvas Size in Pixels
        stage.setTitle("Arkanoid"); // Set window title
        root.getChildren().add(canvas);
        stage.setScene(scene);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // YOUR CODE STARTS HERE
        // Declaring variables
        Scanner sc = new Scanner(System.in);
        int rowNumber = 0;
        int rowColumn= 0;
        int currentScore = 0;
        int highScore = 0;
        int currentLevel = 0;
        int ballX = 0;
        int ballY = 0;
        int paddleX = 0;
        int count = 0;
        boolean go = false;

        // Receiving user input to determine the stage
        do {
            System.out.println("How many rows of bricks (1-10): ");
            rowNumber = sc.nextInt();
            sc.nextLine(); //Clearing the line

            go = rowNumber >= 1 && rowNumber <= 10;
        } while (!go);
        go = false;

        do {
            System.out.println("How many columns of bricks (1-10): ");
            rowColumn = sc.nextInt();
            sc.nextLine(); //Clearing the line

            go = rowColumn >= 1 && rowColumn <= 10;
        } while (!go);
        go = false;

        do {
            System.out.println("What is the current score (1-5000): ");
            currentScore = sc.nextInt();
            sc.nextLine(); //Clearing the line

            go = currentScore >= 1 && currentScore <= 5000;
        } while (!go);
        go = false;

        do {
            System.out.println("What is the high score (1-10000): ");
            highScore = sc.nextInt();
            sc.nextLine(); //Clearing the line

            go = highScore >= 1 && highScore <= 10000;
        } while (!go);
        go = false;

        do {
            System.out.println("What level are you on (1-20): ");
            currentLevel = sc.nextInt();
            sc.nextLine(); //Clearing the line

            go = currentLevel >= 1 && currentLevel <= 20;
        } while (!go);
        go = false;

        do {
            System.out.println("What is the balls x position (1-200): ");
            ballX = sc.nextInt();
            sc.nextLine(); //Clearing the line

            go = (ballX >= 1 && ballX <= 200);
        } while (!go);
        go = false;

        do {
            System.out.println("What is the balls y position (1-200): ");
            ballY = sc.nextInt();
            sc.nextLine(); //Clearing the line

            go = ballY >= 1 && ballY <= 200;
        } while (!go);
        go = false;

        do {
            System.out.println("What is the paddle x position (1-200): ");
            paddleX = sc.nextInt();
            sc.nextLine(); //Clearing the line

            go = paddleX >=1 && paddleX <=200;
        } while (!go);
        go = false;


        // Processing Code below for displaying multiple features



        // The side bar that displays The score, level, highscore
        gc.setFill(Color.LIGHTSKYBLUE);
        gc.fillRect(500,0,300,700);

        gc.setFill(Color.WHITE);
        gc.setFont( new Font("Arial", 40) );
        gc.fillText("Arkanoid",525,40);

        gc.setFill(Color.WHITE);
        gc.setFont( new Font("Arial", 25) );
        gc.fillText("High Score: ",525,90);
        gc.setFill(Color.WHITE);
        gc.setFont( new Font("Arial", 25) );
        gc.fillText(String.valueOf(highScore), 525,120); //user input for high score

        gc.setFill(Color.WHITE);
        gc.setFont( new Font("Arial", 25) );
        gc.fillText("Current Score: ",525,200);
        gc.fillText(String.valueOf(currentScore), 525, 230); //user input for current score

        gc.setFill(Color.WHITE);
        gc.setFont( new Font("Arial", 25) );
        gc.fillText("Level: ",525,300);
        gc.fillText(String.valueOf(currentLevel), 525,330); //user input for level

        // Code for columns and rows of bricks
        for(int i = 0; i < rowNumber; i++) {
            Rectangle r = new Rectangle();
            for (int j = 0; j < rowColumn; j++) {
                r.setTopLeft_x(15 + j * 45);
                r.setTopLeft_y(15 + i * 30);
                r.draw(gc);
            }
        }
        // Code for position of the paddle on the X axis
        for(int p = 0; p < paddleX; p++) {
            Rectangle r = new Rectangle();
            for (int s = 0; s < paddleX; s++) {
                r.setTopLeft_x(paddleX);
                r.setTopLeft_y(600);
                r.draw(gc);
            }
        }
        // Code for position of the ball on the X and Y axis
        for(int d = 0; d < ballX; d++) {
            Circle c = new Circle();
            for (int e = 0; e < ballY; e++) {
                c.setRadius(15);
                c.setCenter(ballX, ballY);
                c.draw(gc);
            }
        }

        // YOUR CODE STOPS HERE
        stage.show();
    }

    /**
     * The actual main method that launches the app.
     *
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);
    }
}