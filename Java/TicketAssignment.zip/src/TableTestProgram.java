import java.io.File;
import java.util.Scanner;
import java.io.FileInputStream;
import java.util.Scanner;


/**
 * Write a description of class Preferences here.
 *
 * @author Husam Abdelhalim - 000104532
 * @version 03/14/2024
 */
public class TableTestProgram
{


    /**
     *
     * Main Program that calls the codes.txt file
     * allows change/display of the document
     * @param args  the args.
     * @throws   Exception

     */
    public static void main(String[] args ) throws Exception
    {


        Scanner in = new Scanner(System.in);
        String tablename = "";
        String choice = "";
        int row = -1;
        int colNum = 1;
        String key = "";
        String s_colNum = "";
        String newValue = "";

        System.out.print("Enter the name of the tab delimited text file you wish to manage (e.g. codes.txt) > ");
        tablename = in.nextLine();
        Table t = new Table(tablename);
        System.out.println("Successfully loaded: " + t);


        while (1==1) {
            System.out.println("\n\nTable Testing Menu\n");

            System.out.println("1. Display all data");
            System.out.println("2. Lookup");
            System.out.println("3. Search");
            System.out.println("4. Change");
            System.out.println("5. Save data to " + tablename);
            System.out.println("9. Quit");
            System.out.print("Select > ");
            choice = in.nextLine();

            if (choice.equals("9")) break;
            if (choice.equals("1")) t.display();
            if (choice.equals("2")) {
                System.out.print("Enter the key > ");
                key = in.nextLine();
                int rowNumber = t.lookup(key);

                if (rowNumber>=0)
                    System.out.println("found " +key+ " at row = " + String.format("%d",rowNumber));
                else
                    System.out.println(key + " not found.");
            }
            if (choice.equals("3")){
                System.out.print("Enter the key > ");
                key = in.nextLine();

                String[] answer;
                answer = t.getMatches(key);

                if (answer != null) {
                    for(int i=0; i<answer.length; i++)
                        System.out.println(answer[i]);
                }
                else System.out.println("No matches!");
            }
            if (choice.equals("4")) {
                System.out.print("Enter the key or row number to change value: ");
                String userInput = in.nextLine();

                try {
                    int rowNum = Integer.parseInt(userInput) - 1;

                    System.out.print("Enter column number: ");
                    s_colNum = in .nextLine();
                    try {
                        colNum = Integer.parseInt(s_colNum);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid column number. Please enter a valid integer.");
                        break;
                    }

                    System.out.print("Enter new value: ");
                    newValue = in .nextLine();

                    t.change(rowNum, colNum, newValue);
                } catch (NumberFormatException e) {

                    System.out.print("Enter column number: ");
                    String col = in.nextLine();


                    try {
                        colNum = Integer.parseInt(col);
                    } catch (NumberFormatException ex) {
                        System.out.println("Invalid column number. Please enter a valid integer.");
                        break;
                    }

                    System.out.print("Enter new value: ");
                    newValue = in .nextLine();

                    t.change(userInput, colNum, newValue);
                }


            }
            if(choice.equals("5")) {
                t.save();

            }

        }

        System.out.println("Thank-you, good bye!");

    }
}
       
       

