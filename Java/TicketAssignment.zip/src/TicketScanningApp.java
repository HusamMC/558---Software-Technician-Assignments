import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * Use this template to create Apps with Graphical User Interfaces.
 *
 * @author YOUR NAME
 */
public class TicketScanningApp extends Application {

    // TODO: Instance Variables for View Components and Model
    private Table t;
    private Label display;
    private Label message;
    private Label footer;
    private TextField input;
    private Button redeem;
    private Button reset;
    private MediaPlayer soundPlayer;
    private MediaPlayer invalidSoundPlayer;

    // TODO: Private Event Handlers and Helper Methods

    /**
     *
     * Reset
     *
     */
    public void reset() {

        for(int r=0; r < t.getNumRows(); r++)
            t.change(r, 2, "N");
        t.save();
    }


    /**
     *
     * Redeem button that resets/reedems and
     * applies sound.
     *
     * @param e  the e.
     */
    private void redeemButton (ActionEvent e) {


        String userInput = input.getText().trim();

        int rowIndex = t.lookup(userInput);

        if(rowIndex != -1) {

            String purchaseStatus = t.getGrid()[rowIndex][1];
            String duplicateStatus = t.getGrid()[rowIndex][2];

            if ("Y".equals(purchaseStatus)) {
                // Display valid message if the ticket is purchased
                message.setText(userInput + " - Valid!");
                message.setStyle("-fx-text-fill: green;");

                if ("Y".equals(duplicateStatus)) {
                    // Display a message for duplicate scan
                    message.setText(userInput + " is a duplicate");
                    message.setStyle("-fx-text-fill: red;");
                    footer.setText(t.getGrid()[rowIndex][3]);
                    footer.setStyle("-fx-text-fill: red;");
                    invalidSoundPlayer.play();
                    invalidSoundPlayer.seek(invalidSoundPlayer.getStartTime());
                } else {
                    // Display a message for a non-duplicate scan
                    footer.setText(t.getGrid()[rowIndex][3]);
                    footer.setStyle("-fx-text-fill: green;");
                    soundPlayer.play();
                    soundPlayer.seek(soundPlayer.getStartTime());
                }
            } else {
                // Display a message for an unpurchased ticket
                message.setText(userInput + " not purchased yet");
                message.setStyle("-fx-text-fill: red;");
                footer.setText(t.getGrid()[rowIndex][3]);
                footer.setStyle("-fx-text-fill: red;");
                invalidSoundPlayer.play();
                invalidSoundPlayer.seek(invalidSoundPlayer.getStartTime());
            }
        } else {
            // Display an invalid message if the user input does not match any code
            message.setText("INVALID code");
            message.setStyle("-fx-text-fill: red;");
            footer.setText("");
            invalidSoundPlayer.play();
            invalidSoundPlayer.seek(invalidSoundPlayer.getStartTime());
        }

        if ("RESET".equals(userInput)) {
            // If the user input is "RESET", perform the system reset
            reset();
            message.setText("Successfully reset");
            message.setStyle("-fx-text-fill: green;");
            return;
        }
    }


    /**
     * This is where you create your components and the model and add event
     * handlers.
     *
     * @param stage The main stage
     * @throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {

        Pane root = new Pane();
        Scene scene = new Scene(root, 400, 225); // set the size here
        stage.setTitle("TicketScanningApp"); // set the window title here
        stage.setScene(scene);
        // TODO: Add your GUI-building code here

        // 1. Create the model
        t = new Table("codes.txt");



        // 2. Create the GUI components
        display = new Label("Ticket Scanning App");
        message = new Label("Welcome to Fan Expo!!!");
        footer = new Label("");
        redeem = new Button("Redeem");
        reset = new Button("Reset");
        input = new TextField("Enter Code");

        Media valid = new Media(getClass().getResource("assets/valid.wav").toString());
        soundPlayer = new MediaPlayer(valid);
        Media invalidSound = new Media(getClass().getResource("assets/invalid.wav").toString());
        invalidSoundPlayer = new MediaPlayer(invalidSound);


        // 3. Add components to the root
        root.getChildren().addAll(display, message, footer, redeem, input, reset);


        // 4. Configure the components (colors, fonts, size, location)
        display.setPrefWidth(500);
        display.relocate(10, 10);
        display.setStyle("-fx-text-fill: #191970");
        display.setFont(new Font("Serif", 20));

        input.setPrefWidth(100);
        input.setPrefHeight(50);
        input.relocate(30, 70);


        redeem.setPrefWidth(100);
        redeem.setPrefHeight(50);
        redeem.relocate(150, 70);
        redeem.setStyle("-fx-font-size: 20px;");
        redeem.setStyle("-fx-border-color: red; ");

        reset.setPrefWidth(100);
        reset.setPrefHeight(50);
        reset.relocate(275, 70);
        reset.setStyle("-fx-font-size: 20px;");
        reset.setStyle("-fx-border-color: red; ");



        message.relocate(90, 150);
        message.setFont(new Font("Serif", 20));


        footer.relocate(30, 185);



        // 5. Add Event Handlers and do final setup
        redeem.setOnAction(this::redeemButton);
        reset.setOnAction(event -> reset());

        input.setOnKeyReleased(event -> {
            if(event.getCode() == KeyCode.ENTER) {
                redeemButton(new ActionEvent());
            }
        });


        // 6. Show the stage
        stage.show();
    }

    /**
     * Make no changes here.
     *
     * @param args unused
     */
    public static void main(String[] args) {

        launch(args);
    }
}
