import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * This class manages anu tab delimited text file, e.g.  codes.txt
 *
 * @author Dave Slemon, Husam Abdelhalim
 * @version v100, 03/14/2024
 */
public class Table
{ //class

    //instance variables
    private String tableName;
    private int numRows;
    private int numCols;
    private String[][] grid;



    /**
     *
     * Initialize the class with the name of the tab delimited text file you wish to manage.
     *
     * @param filename  the name of tab delimited text file.
     */

    public Table( String filename )
    { //table
        tableName = filename;
        numRows=0;
        numCols=0;
        String s;
        int r;
        String[] item;



        //Pass1:  Go through the text file in order to ascertain the
        //        numRows and numCols
        try {


            Scanner theFile = new Scanner(new FileInputStream(new File (tableName)));
            while ( theFile.hasNextLine() )
            {
                s = theFile.nextLine();
                item = s.split("\t", 0);


                if (item.length > numCols)
                    numCols = item.length;

                numRows++;

            }
            theFile.close();
        }
        catch (FileNotFoundException  e)
        {
            System.out.println("Table class error 1: file not found.");
        }


        grid = new String[numRows][numCols];


        //Pass2:  populate the grid array
        try {

            Scanner theFile = new Scanner(new FileInputStream(new File (tableName)));
            r=0;
            while ( theFile.hasNextLine() )
            {
                s = theFile.nextLine();
                item = s.split("\t", 0);

                for(int c=0; c < numCols; c++) {

                    if ( item[c].length() == 0)
                        grid[r][c] = "";
                    else
                        grid[r][c] = item[c];
                }
                r++;
            }
            theFile.close();
        }
        catch (Exception e)
        {
            System.out.println("Table class error 2: file not found.");
        }

    } //table


    /**
     *
     * Gets the num rows
     *
     * @return the num rows
     */
    public int getNumRows() {


        return numRows;
    }

    /**
     * Gets the num cols
     *
     * @return the num cols
     */
    public int getNumCols() {


        return numCols;
    }

    /**
     *
     * Saves changes by the user
     *
     */
    public void save() {

        try {
            FileWriter writer = new FileWriter(tableName);
            for (int i = 0; i < numRows; i++) {
                for (int j = 0; j < numCols; j++) {
                    writer.write(grid[i][j]);
                    if (j < numCols - 1) {
                        writer.write("\t");
                    }
                }
                writer.write("\n");
            }
            writer.close();
            System.out.println("Table saved successfully, " + tableName + " updated!");
        } catch (IOException e) {
            System.out.println("Error saving the table to file: " + e.getMessage());
        }
    }

    /**
     *
     * Change to a specific col based on
     * row num information provided.
     *
     * @param rowNum  the row num.
     * @param colNum  the col num.
     * @param newValue  the new value.
     */
    public void change(int rowNum, int colNum, String newValue) {

        this.numCols= colNum;
        this.numRows = rowNum;
        grid[rowNum][colNum] = newValue;
        System.out.println("Change successful.");

    }

    /**
     *
     * Change to a specific col based on
     * information provided.
     *
     * @param key  the key.
     * @param colNum  the col num.
     * @param newValue  the new value.
     */
    public void change(String key, int colNum, String newValue) {


        for (int i = 0; i < numRows; i++) {
            if (grid[i][0].equals(key)) {
                if (colNum >= 0 && colNum < numCols) {
                    grid[i][colNum] = newValue;
                    System.out.println("Change successful.");
                    return;
                } else {
                    System.out.println("Invalid column number. Please enter a valid column number.");
                    return;
                }
            }
        }
        System.out.println("Unable to change. Key not found");
    }



    /**
     *
     * Sets the num cols
     * not in use currently
     * @param numCols  the num cols.
     */
    public void setNumCols(int numCols) {

        this.numCols = numCols;
    }


    /**
     *
     * Gets the grid
     *
     * @return the grid
     */
    public String[][] getGrid() {

        return grid;
    }


    /**
     *
     * Sets the grid
     *
     * @param grid  the grid.
     */
    public void setGrid(String[][] grid) {

        this.grid = grid;
    }




    /**
     *
     * Displays all the information
     * from the codes.txt file.
     *
     * @throws //goes to each cell of the grid
    for(int r=0; r< grid.length; r++
     */
    public void display(){//goes to each cell of the grid
        for(int r=0; r< grid.length; r++){

            for(int c=0; c<grid[r].length; c++){
                System.out.print(grid[r][c] + "\t");
            }
            System.out.println();
        }
    }

    // @param key - is the primary key of the line
    // @return if key not found, returns -1

    /**
     *
     * Lookup the codes.txt file
     *
     * @param key  the key.
     * @return int
     */
    public int lookup(String key){


        for(int r=0; r<grid.length; r++){
            if (key.equals(grid[r][0])){
                return r;
            }
        }
        return -1;
    }



    /**
     *
     * Gets the matches as per userinput
     * from the codes.txt file
     *
     * @param key  the key.
     * @return the matches
     */
    public String [] getMatches(String key){

        int rowNum = lookup(key);
        if (rowNum < 0) return null;
        return getMatches(rowNum);
    }


    /**
     *
     * Gets the matches
     *
     * @param rowNum  the row num.
     * @return the matches
     */
    public String [] getMatches(int rowNum){

        String[] result = new String[numCols];
        if (rowNum >= 0 && rowNum < grid.length){
            for(int c=0; c< numCols; c++){
                result[c] = grid[rowNum][c];
            }
            return result;
        }
        return null;
    }



    /**
     *
     * To string
     *
     * @return String
     */
    public String toString() {


        return ("Table: " + tableName + "  rows = " + numRows + "  cols = " + numCols);
    }

} //class



