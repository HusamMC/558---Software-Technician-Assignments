import java.util.Random;

public class Obstacle {

    public static void main(String[] args) {

        int one = 0;
        int two = 0;
        int three = 0;
        int four = 0;
        int five = 0;
        int six = 0;


        Die dumpObject = new Die();

        int[ ] diceArray = new int[1000000];

        for (int x = 0; x < diceArray.length; x++) {
            diceArray[x] = dumpObject.roll();
            if (diceArray[x] == 1) {
                one++;
            }
            else if (diceArray[x] == 2) {
                two++;
            }
            else if (diceArray[x] == 3) {
                three++;
            }
            else if (diceArray[x] == 4) {
                four++;
            }
            else if (diceArray[x] == 5) {
                five++;
            }
            else if (diceArray[x] == 6){
                six++;
            }

        }
        System.out.println(1+": "+one+"\n"+2+": "+two+"\n"+3+": "+three+"\n"+4+": "+four+"\n"+5+": "+five+"\n"+6 +": "+six);
        
    }

}
