public class TestProgram {

    public static void main (String [] args) {

        //Die red = new Die( ); //makes a 6 sided die
        //Die red= new Die(2); //make a 2 sided coin
        //Die red = new Die(6,1);// makes a 6 sided die with 1 showing

        //System.out.println(red);   //displays top number

        //System.out.println( red.roll() ); //display a random face
        int [ ] freq = new int[7];


        Die [ ] d= new Die[5];
        for (int i=0; i<d.length; i++){

            d [i] = new Die(6);
        }

        for (int r=0; r<d.length; r++){
            d[r].roll();
            freq[r] = 0;

        }
        for (int y=0; y<d.length; y++) { //no curley braces cause 1 for statement
            int amt = d[y].getCurrentFace();
            freq[amt]++;
            System.out.print(d[y] + "  ");
        }
        System.out.println();

        for (int x=0; x< freq.length; x++)
            System.out.printf("%d: %d\n",x,freq[x]);




    }
}
