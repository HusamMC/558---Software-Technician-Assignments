

import java.util.Random;


/**
 * This Die class represents the actions of a SINGLE
 * die of any number of faces.
 *
 * @author: Dave Slemon
 * @verion: 100
 */
public class Die {

    //instance variables
    private int numberOfFaces;
    private int currentFace;



    /**
     *
     * This constructor can create a die with numberOfFaces
     *
     * @param numberOfFaces  the number of faces the die has
     */
    public Die(int numberOfFaces) {

        this.numberOfFaces = numberOfFaces;
        this.currentFace = 1;
    }





    /**
     *
     * This default constructor creates a 6-sided die.
     *
     */
    public Die() {

        this(6);
    }





    /**
     *
     * Gets the current face or number that appears face up on the die.
     *
     * @return the current face, i.e. number which is face up
     */
    public int getCurrentFace() {

        return currentFace;
    }






    /**
     *
     * This routine, simulates the rolling of a die.
     *
     * @return an int which is the face up value
     */
    public int roll(){

        Random r = new Random();
        currentFace = r.nextInt(numberOfFaces)+1;
        return currentFace;
    }






    /**
     *
     * Displays the current value of the die.
     *
     * @return the face up value of the die.
     */
    public String toString()
    {

        return String.format("%d",currentFace);
    }





    /**
     Provides a random int between minimum and maximum,not including maximum
     @return minimum <= num < maximum
     */
    public static int getRandomInteger( int minimum, int maximum)
    {
        return ((int) (Math.random() * (maximum - minimum))) + minimum;
    }

}
