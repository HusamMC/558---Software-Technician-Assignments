import java.util.Arrays;
import java.util.Random;


/**
 * Author@ Husam Abdelhalim
 * Date@ 03/25/2024
 */
public class DeckOfCards {
    private Card[] deck;
    private int numSuits;
    private int maxRank;
    private Card topCard;


    /**
     *
     * Deck of cards constructor that
     * use the max rank and num of suits
     * to fill with array of cards
     *
     * @param maxRank  the max rank.
     * @param numSuits  the num suits.
     */
    public DeckOfCards(int maxRank, int numSuits) {

        if (maxRank <= 0 || numSuits <= 0) {
            System.out.println("Both maxRank and numSuits must be greater than 0.");
            return;
        }

        this.numSuits = numSuits;
        this.maxRank = maxRank;
        int totalCards = numSuits * maxRank;
        deck = new Card[totalCards];

        int index = 0;
        for (int suit = 1; suit <= numSuits; suit++) {
            for (int rank = 1; rank <= maxRank; rank++) {
                deck[index++] = new Card(suit, rank);
            }
        }
    }


    /**
     *
     * Shuffle the deck and updates
     * the top card.
     *
     */
    public void shuffle() {

        Random random = new Random();
        for (int i = deck.length - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            Card temp = deck[index];
            deck[index] = deck[i];
            deck[i] = temp;
        }
        updateTopCard();
    }



    /**
     *
     * Deal cards
     *
     * @param numCards  the num cards.
     * @return Card[]
     */
    public Card[] dealCards(int numCards) {

        if (numCards <= 0) {
            System.out.println("Number of cards to deal must be greater than 0.");
            return null;
        }

        Card[] hand = new Card[numCards];
        for (int i = 0; i < numCards; i++) {
            if (deck.length == 0) {
                System.out.println("Deck is empty.");
                return hand;
            }
            hand[i] = deck[deck.length - 1];
            deck = Arrays.copyOf(deck, deck.length - 1);
        }
        return hand;
    }


    /**
     *
     * Update top card
     *
     */
    private void updateTopCard() {


        if (deck.length > 0) {
            topCard = deck[0];
        } else {
            topCard = null;
        }
    }

    /**
     *
     * Gets the top card
     *
     * @return the top card
     */
    public Card getTopCard() {


        return topCard;
    }


    /**
     *
     * Gets the size of the deck
     *
     * @return the size
     */
    public int getSize() {

        return this.deck.length;
    }


    /**
     *
     * Gets the min value
     *
     * @return the min value
     */
    public int getMinValue() {

        return 1;
    }


    /**
     *
     * Gets the max value
     *
     * @return the max value
     */
    public int getMaxValue() {

        return numSuits * maxRank;
    }


    /**
     *
     * To string
     *
     * @return String
     */
    public String toString() {

        return "Deck size: " + getSize() + ", Min Value: " + getMinValue() + ", Max Value: " + getMaxValue() + ", Top Card: " + deck[deck.length - 1];
    }


    /**
     *
     * Histogram method
     *
     * @param numCardsInHand  the num cards in hand.
     * @return int[]
     */
    public int[] histogram(int numCardsInHand) {

        int[] histogram = new int[(numSuits * maxRank * numCardsInHand) + 1];

        for (int i = 0; i < 100000; i++) {
            shuffle();
            Card[] hand = dealCards(numCardsInHand);

            if (hand != null) {
                int totalValue = 0;
                for (Card card : hand) {
                    if (card != null) {
                        totalValue += card.getValue();
                    }
                }
                if (totalValue < histogram.length) {
                    histogram[totalValue]++;
                }
            }

            deck = new Card[numSuits * maxRank];
            int index = 0;
            for (int suit = 1; suit <= numSuits; suit++) {
                for (int rank = 1; rank <= maxRank; rank++) {
                    deck[index++] = new Card(suit, rank);
                }
            }
        }

        return histogram;
    }



}
