import java.util.Scanner;
/**
 * Author@ Husam Abdelhalim
 * Date@ 03/25/2024
 */
public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int suits;
        int ranks;

        System.out.println("How many suits?: ");
        suits = scanner.nextInt();
        scanner.nextLine(); //clear the line

        System.out.println("How many ranks?: ");
        ranks = scanner.nextInt();
        scanner.nextLine(); //clear the line

        DeckOfCards d = new DeckOfCards(suits, ranks);

        boolean deck = true;

        while (deck) {
            System.out.println("What do you want to do? " +
                    "1 = Shuffle, 2 = Deal 1 hand,  3 = Deal 100,000 times, 4 = Quit: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); //clear the line

            if (choice == 1) {
                d.shuffle();
                System.out.println("Deck size: " + d.getSize() + ", low = 1, high = " + d.getMaxValue() + ", Top Card  = " + d.getTopCard());
            } else if (choice == 2) {
                int numDeal;
                System.out.println("How many cards? ");
                numDeal = scanner.nextInt();
                scanner.nextLine(); //clear the line
                Card[] hand = d.dealCards(numDeal);
                if (hand != null) {
                    System.out.println("Hand dealt: ");
                    for (Card card : hand) {
                        System.out.println(card);
                    }
                }
            } else if (choice == 3) {
                System.out.println("Dealing 100,000 times...");
                int[] histogram = d.histogram(5);
                for (int i = 1; i <= d.getMaxValue(); i++) {
                    if (histogram[i] != 0) {
                        int roundedCount = (histogram[i] + 500) / 1000 * 1000;
                        int stars = roundedCount / 1000;
                        String output = String.format("%2d: \t%5d \t%s", i, histogram[i], "*".repeat(stars));
                        System.out.println(output);
                    }
                }
            } else if (choice == 4) {
                System.out.println("Goodbye");
                deck = false;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
