/**
 * Author@ Husam Abdelhalim
 * Date@ 03/25/2024
 */
public class Card {

    private int suit;
    private int rank;
    private int value;


    /**
     *
     * It is a constructor.
     *
     * @param suit  the suit.
     * @param rank  the rank.
     */
    public Card(int suit, int rank) {

        if (suit > 0 && rank > 0) {
            this.suit = suit;
            this.rank = rank;
            this.value = rank * suit;
        } else {
            System.out.println("Both suit and rank must be greater than 0 and positive integers");
        }
    }


    /**
     *
     * Gets the suit
     *
     * @return the suit
     */
    public int getSuit() {

        return this.suit;
    }


    /**
     *
     * Gets the rank
     *
     * @return the rank
     */
    public int getRank() {

        return this.rank;
    }


    /**
     *
     * Gets the value
     *
     * @return the value
     */
    public int getValue() {

        return this.value;
    }

    @Override

/**
 *
 * To string
 *
 * @return String
 */
    public String toString() {

        return "Rank: " + rank + ", Suit: " + suit;
    }
}


