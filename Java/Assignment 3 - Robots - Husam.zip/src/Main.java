import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.Random;

import static javafx.application.Application.launch;

/**
 * Use this template to create drawings in FX. Change the name of the class and
 * put your own name as author below. Change the size of the canvas and the
 * window title where marked and add your drawing code where marked.
 *
 * @author Husam Abdelhalim - 000104532
 * February 05/ 2024
 */
public class Main extends Application {

    /**
     * Start method (use this instead of main).
     *
     * @param stage The FX stage to draw on
     * @throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {
        Group root = new Group();
        Scene scene = new Scene(root);
        Canvas canvas = new Canvas(600, 600); // Set canvas Size in Pixels
        stage.setTitle("Main"); // Set window title
        root.getChildren().add(canvas);
        stage.setScene(scene);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // YOUR CODE STARTS HERE
        //Background Color
        gc.setFill(Color.BEIGE);
        gc.fillRect(0,0, 600,600);
        Random random = new Random();
        //Array of teams
        String[] teams = new String[] {"Sudan", "Italy", "Iceland"};
        //calling random colors for each team.
        Color color1 = Color.color(Math.random(), Math.random(), Math.random());
        Color color2 = Color.color(Math.random(), Math.random(), Math.random());
        Color color3 = Color.color(Math.random(), Math.random(), Math.random());
        //initializing 3 teams
        Team team1;
        Team team2;
        Team team3;
        //positioning players on teams and averages
        if (random.nextInt(3) == 0) {
            team1 = new Team(teams[0], 20, 30, color1);
            team2 = new Team(teams[1], 20, 200, color2);
            team3 = new Team(teams[2], 20, 400, color3);
        } else if (random.nextInt(3) == 1) {
            team1 = new Team(teams[0], 20, 30, color1);
            team2 = new Team(teams[1], 20, 200, color2);
            team3 = new Team(teams[2], 20, 400, color3);
        } else {
            team1 = new Team(teams[0], 20, 30, color1);
            team2 = new Team(teams[1], 20, 200, color2);
            team3 = new Team(teams[2], 20, 400, color3);
        }
        //drawing the 3 teams.
        team1.draw(gc);
        team2.draw(gc);
        team3.draw(gc);
        //initializing the referee
        int refereeTeam = random.nextInt(3);
        Player ref;
        //giving the referee the title of the winning team.
        if (refereeTeam == 2) {
            ref = new Player(450, 200, 50,50, Color.RED, "Referee " + teams[0]);
        } else if (refereeTeam == 1) {
            ref = new Player(450, 200, 50,50, Color.RED, "Referee " + teams[1]);
        } else {
            ref = new Player(450, 200, 50,50, Color.RED, "Referee " + teams[2]);
        }

        ref.draw(gc);
        stage.show();
        // YOUR CODE STOPS HERE

    }

    /**
     * The actual main method that launches the app.
     *
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);
    }
}