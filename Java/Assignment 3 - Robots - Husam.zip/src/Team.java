import javafx.scene.paint.Color;
import javafx.scene.canvas.GraphicsContext;

/**
 * Instance variables for the teams
 */
public class Team {

    private double x;
    private double y;
    private String name;
    private Player player1;
    private Player player2;
    private Player player3;





    /**
     * Constructor for creating the Team.
     */
    public Team(String name, double x, double y, Color color) {
        this.name = name;
        this.x = x;
        this.y = y;
        player1 = new Player(x, y, color);
        player2 = new Player(x + 90.0, y, color);
        player3 = new Player(x + 180, y, color);

    }





    /**
     * Initializing the player constructors
     * Calling the averages and formatting
     * the text.
     */
    public void draw(GraphicsContext gc) {
        //Draw Players
        this.player1.draw(gc);
        this.player2.draw(gc);
        this.player3.draw(gc);
        //get player Averages
        double avg = (this.player1.getAverage() + this.player2.getAverage() + this.player3.getAverage()) / 3.0;
        gc.setFill(Color.BLACK);
        String blend = this.name;
        gc.fillText(blend + " Team Average " + String.format("%.2f%%", avg), this.x, this.y + 140);

    }

}
