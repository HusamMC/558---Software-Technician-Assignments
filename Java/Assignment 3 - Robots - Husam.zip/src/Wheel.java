import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
/**
 * Instance variables for the wheel shape
 */
public class Wheel {

    private double x;
    private double y;
    private double w;
    private double h;
    private Color color;






    /**
     * Constructor for wheel
     */
    public Wheel(double x, double y, double w, double h, Color color) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.color = color;
    }






    /**
     * Initializing the wheel1 and wheel2 in draw
     * first FillOval refers wheel1
     * Second FillOval refers to wheel2
     */
    public void draw(GraphicsContext gc) {
        //draw shape

        gc.setFill(this.color);
        gc.fillOval(x, y, w, h);

        gc.setFill(this.color);
        gc.fillOval(x, y, w, h);

    }
}
