import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * Instance variables for the Head
 * and neck shape
 */
public class Head {
    private double x;
    private double y;
    private double w = 40.0;
    private double h = 25.0;
    private Color color;






    /**
     * Constructor for Calling the Head
     */
    public Head(double x, double y, Color color) {
        this.x = x;
        this.y = y;
        this.color = color;
    }






    /**
     * Initializing the head and neck in draw
     * first FillRect refers to the head with
     * set W and H.
     * Second FillRec is for the neck.
     */
    public void draw(GraphicsContext gc) {
        //draw shape
        gc.setFill(color);
        gc.fillRect(x, y, this.w, this.h); //Head
        gc.fillRect(x, y, w, h); //Neck
        //fill shape
        gc.setFill(color);
        gc.fillRect(x+10,y+19, w*0.5, h*0.5);


    }


}
