import javafx.scene.paint.Color;
import javafx.scene.canvas.GraphicsContext;

/**
 * Instance variables for the players
 */
public class Player {
    private double x;
    private double y;
    private double h;
    private double w;
    private double average;
    private Color color;
    private String title;
    private Head head1;
    private Wheel wheel1, wheel2;






    /**
     * Constructor for creating the players
     * on each team.
     */
    public Player(double x, double y, Color color){
        this.x = x;
        this.y = y;
        this.h = 30;
        this.w = 15;
        this.color = color;
        this.average = (double) Math.round(Math.random() * 100.0 * 100.0) / 100.0;
        this.title = " ";
        head1 = new Head(x+23,y+10, color);
        wheel1 = new Wheel(x, y+80, w, h, color);
        wheel2 = new Wheel(x+70, y+80, w , h, color);

    }





    /**
     * Constructor for creating the referee
     * of the winning team
     */
    public Player(double x, double y, double w, double h, Color color, String title) {
        this.x = x;
        this.y = y;
        this.h = h;
        this.w = w;
        this.title = title;
        this.color = color;
        this.average = 100;
        head1 = new Head(x + 23,y+10, color);
        wheel1 = new Wheel(x, y+80, w*0.30, h*0.5, color);
        wheel2 = new Wheel(x+70, y+80, w*0.30, h*0.5, color);

    }




    /**
     * getting the average of the players
     */
    public double getAverage () {
        return this.average;
    }




    /**
     * Initializing the players in draw
     * Initializing the text of the averages.
     * Calling the Wheel constructors
     * Calling the Head and Neck Constructors
     */
    public void draw(GraphicsContext gc) {
        //draw shape
        gc.setFill(this.color);
        gc.fillOval(this.x + 10.0, this.y + 40.0, 65.0, 65.0);
        gc.setFill(Color.BLACK);
        gc.fillText("" + this.average, this.x + 28.0, this.y + 75.0);
        gc.fillText(this.title, this.x, this.y + 130.0);

        //Calling Wheel constructor
        wheel1.draw(gc);
        wheel2.draw(gc);

        //Calling Head constructor
        head1.draw(gc);
    }















}



