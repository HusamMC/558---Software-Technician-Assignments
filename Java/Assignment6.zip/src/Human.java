import java.util.Random;
/**
 * Author: Husam Abdelhalim 000104532
 * Date: April 5th, 2024
 */
abstract class Human {
    protected String type;
    protected String name;
    protected int agility;
    protected int strength;
    protected int health;
    protected int magic;
    protected boolean isAlive;


    /**
     *
     * Main Constructor to call the human class
     *
     * @param type  the type.
     * @param name  the name.
     * @param agility  the agility.
     * @param strength  the strength.
     * @param health  the health.
     * @param magic  the magic.
     */
    public Human(String type, String name, int agility, int strength, int health, int magic) {

        this.name = name;
        this.agility = Math.max(5, agility); // Ensure agility is at least 5
        this.strength = Math.max(5, strength); // Ensure strength is at least 5
        this.health = Math.max(1, health); // Ensure health is at least 1
        this.magic = Math.max(0, magic); // Ensure magic is at least 0
        this.type = type;
        isAlive = true;
    }


    /**
     *
     * Method to get the type(Hunter/healer)
     *
     */
    public String getType() {

        return type;
    }


    /**
     *
     * method to gets the name of the human
     *
     */
    public String getName() {

        return name;
    }


    /**
     *
     * Method to return if Human is alive
     *
     */
    public boolean isAlive() {

        return isAlive;
    }


    /**
     *
     * damage calculation method
     *
     * @param damage  the damage.
     */
    public void takeDamage(int damage) {

        if (isAlive) {
            Random rand = new Random();
            int defenseValue = rand.nextInt(10) + 1; // Random defense value between 1 and 10
            int damageTaken = Math.max(1, damage / defenseValue); // Ensure minimum damage taken is 1
            health -= damageTaken;
            if (health <= 0) {
                isAlive = false;
                health = 0;
            }
        }
    }


    /**
     *
     * heal to assign to the healer
     * class
     *
     * @param amount  the amount.
     */
    public void heal(int amount) {

        if (isAlive) {
            health += amount;
        }
    }


    /**
     *
     * to string
     *
     */
    public String toString() {

        return "Human " + getName() + " is a " + getType();
    }
}

