/**
 * Author: Husam Abdelhalim 000104532
 * Date: April 5th, 2024
 */
class Witch extends Creature {

    private Pack pack;


    /**
     *
     * Main constructor to call the witch class
     *
     * @param name  the name.
     * @param agility  the agility.
     * @param health  the health.
     * @param strength  the strength.
     * @param pack  the pack.
     */
    public Witch(String name, int agility, int health, int strength, Pack pack) {

        super(name, Math.max(5, agility), Math.max(5, health), strength); // Ensure agility and health are at least 5
        this.pack = pack;
    }

    @Override

/**
 *
 * Method to Defends against damage
 *
 * @param damage  the damage.
 */
    public void defend(int damage) {

        takeDamage(damage);
    }


    /**
     *
     * To String
     *
     */
    public String toString() {

        return (pack != null) ? "Witch " + getName() + " belongs to " + pack.getNameOfPack() : "Witch " + getName();
    }


    /**
     *
     * Returns the pack
     *
     */
    public Pack getPack() {

        return pack;
    }


    /**
     *
     * Returns the strength to help
     * the healer
     *
     */
    public int getStrength() {

        return strength;
    }
}
