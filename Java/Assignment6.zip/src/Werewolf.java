/**
 * Author: Husam Abdelhalim 000104532
 * Date: April 5th, 2024
 */
class Werewolf extends Creature {

    private Pack pack;


    /**
     *
     * It is a constructor.
     * This is the main constructor that calls a werewolf
     *
     * @param name  the name.
     * @param agility  the agility.
     * @param health  the health.
     * @param strength  the strength.
     * @param pack  the pack.
     */
    public Werewolf(String name, int agility, int health, int strength, Pack pack) {

        super(name, Math.max(5, agility), Math.max(5, health), Math.max(5, strength)); // Ensure all attributes are at least 5
        this.pack = pack;
    }


    /**
     *
     * This is the attack method to test
     * if a a creature can attack another of the same pack
     * or not.
     *
     * @param target  the target.
     */
    public void attack(Creature target) {

        if (isAlive() && target.isAlive() && pack != null && target instanceof Witch && ((Witch) target).getPack() == pack) {
            System.out.println("Cannot attack witch of the same pack.");
            return;
        }
        int damage = (strength + agility + health) / 3;
        System.out.println(getName() + " is attacking " + target.getName() + " with damage: " + damage);
        target.defend(damage);
    }

    @Override

/**
 *
 * Method for defending against damage taken.
 *
 * @param damage  the damage.
 */
    public void defend(int damage) {

        takeDamage(damage);
    }


    /**
     *
     * To string to call the werewolf
     *
     */
    public String toString() {

        return (pack != null) ? "Werewolf " + getName() + " belongs to " + pack.getNameOfPack() : "Werewolf " + getName();
    }
}
