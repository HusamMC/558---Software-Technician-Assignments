/**
 * Author: Husam Abdelhalim 000104532
 * Date: April 5th, 2024
 */
class Hunter extends Human {


    /**
     *
     * Main constructor to assign a human
     * the hunter class
     *
     * @param type  the type.
     * @param name  the name.
     * @param strength  the strength.
     * @param agility  the agility.
     * @param health  the health.
     */
    public Hunter(String type, String name, int strength, int agility, int health) {

        super(type, name, strength, agility, health, 0); // No magic for hunters
    }

    @Override

/**
 *
 * Method for calculating attack damage
 *
 */
    public int getAttackDamage() {

        return (2 * (strength + agility + health)); // Hunters do twice the normal damage
    }

    @Override

/**
 *
 * Method for defending against damage
 *
 * @param damage  the damage.
 */
    public void defend(int damage) {

        takeDamage(damage); // Hunters defend like other humans
    }


    /**
     *
     * To string
     *
     */
    public String toString() {

        return super.toString();
    }
}
