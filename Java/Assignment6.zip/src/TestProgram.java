import java.util.Random;


/**
 * The class Test program
 * Husam Abdelhalim 000104532
 */
public class TestProgram {

    /**
     *
     * Main program testing the Human/Witch/Creature Class
     * as well as the Pack/Hunter/Healer class
     * @param args  the args.
     */
    public static void main(String[] args) {


        Pack p = new Pack("TheCrazys");
        // Testing to see if 2 werewolfs in the same pack can't attack each other
        Werewolf w = new Werewolf("Kato", 5, 5, 5, p);
        Werewolf c = new Werewolf("Cleo", 5, 5, 5, p);

        p.setLeader(w);

        Witch wh = new Witch("Morrigan", 5, 5, 5, p);

        Human hunt = new Hunter("Ranger","Doug", 8, 8, 5);
        Human heal = new Healer("Priest", "Kyle", 3, 3, 8, 10);

        // Displaying the initial status
        System.out.println("Initial Status:");
        System.out.println(p);
        System.out.println(w);
        System.out.println(c);
        System.out.println(wh);
        System.out.println(hunt);
        System.out.println(heal);
        System.out.println();

        // Testing if a Werewolf can attack another Werewolf in the same pack
        System.out.println("Werewolf attacking another Werewolf:");
        w.attack(c);
        System.out.println();

        // Testing if a Werewolf can attack its pack's Witch
        System.out.println("Werewolf attacking Witch:");
        w.attack(wh);
        System.out.println();

        // Testing if a Healer can heal another Human
        System.out.println("Healer healing another Human:");
        ((Healer) heal).healHuman(hunt);
        System.out.println();

        // Testing if a Witch can strengthen a Healer
        System.out.println("Witch strengthening Healer:");
        ((Healer) heal).strengthen(wh.getStrength());
        System.out.println();

        // Displaying the final status
        System.out.println("Final Status:");
        System.out.println(p);
        System.out.println(w);
        System.out.println(c);
        System.out.println(wh);
        System.out.println(hunt);
        System.out.println(heal);
    }
}
