/**
 * Author: Husam Abdelhalim 000104532
 * Date: April 5th, 2024
 */
abstract class Creature {

    protected String name;
    protected int agility;
    protected int strength;
    protected int health;
    protected boolean isAlive;


    /**
     *
     * Main constructor to give a creature
     * stats
     *
     * @param name  the name.
     * @param agility  the agility.
     * @param health  the health.
     * @param strength  the strength.
     */
    public Creature(String name, int agility, int health, int strength) {

        this.name = name;
        this.agility = agility;
        this.strength = strength;
        this.health = health;
        isAlive = true;
    }


    /**
     *
     * method to get the name of the creature
     *
     */
    public String getName() {

        return name;
    }


    /**
     *
     * Method to determine if a creature is alive
     *
     */
    public boolean isAlive() {

        return isAlive;
    }



    /**
     *
     * defends against damage
     * and calculates hp pool when taking damage
     *
     * @param damage  the damage.
     * @throws ;

    public void takeDamage(int damage
     */
    public abstract void defend(int damage);

    public void takeDamage(int damage) {

        if (isAlive) {
            health -= damage;
            if (health <= 0) {
                isAlive = false;
                health = 0;
            }
        }
    }


    /**
     *
     * To string
     *
     */
    public String toString() {

        return name;
    }
}
