/**
 * Author: Husam Abdelhalim 000104532
 * Date: April 5th, 2024
 */
class Healer extends Human {


    /**
     *
     * Main constructor to call the healer class
     *
     * @param type  the type.
     * @param name  the name.
     * @param strength  the strength.
     * @param agility  the agility.
     * @param health  the health.
     * @param magic  the magic.
     */
    public Healer(String type, String name, int strength, int agility, int health, int magic) {

        super(type, name, strength, agility, health, magic);
    }

    @Override

/**
 *
 * Method for healer damage
 *
 */
    public int getAttackDamage() {

        return 0;
    }

    @Override

/**
 *
 * Method to defend against damage
 *
 * @param damage  the damage.
 */
    public void defend(int damage) {

        takeDamage(damage);
    }


    /**
     *
     * Method to heal other humans
     *
     * @param target  the target.
     */
    public void healHuman(Human target) {

        if (isAlive() && target.isAlive()) {
            if (magic > 0) {
                int healingScore = (int) (magic / 2.5);
                target.heal(healingScore);
                magic--;
            }
        }
    }


    /**
     *
     * Method to receive strength from witch
     *
     * @param witchStrength  the witch strength.
     */
    public void strengthen(int witchStrength) {

        if (isAlive()) {
            magic += witchStrength / 3;
        }
    }


    /**
     *
     * It is a constructor.
     *
     */
    public String toString() {

        return super.toString();
    }
}
