/**
 * Author: Husam Abdelhalim 000104532
 * Date: April 5th, 2024
 */
class Pack {

    private String nameOfPack;
    private Werewolf leader;
    private Witch witch;


    /**
     *
     * Main constructor for assigning a creature to a pack
     *
     * @param nameOfPack  the name of pack.
     */
    public Pack(String nameOfPack) {

        this.nameOfPack = nameOfPack;
        this.leader = null;
        this.witch = null;
    }


    /**
     *
     * Constructor for assigning a creature to a pack
     * and if it is the leader.
     *
     * @param nameOfPack  the name of pack.
     * @param leader  the leader.
     */
    public Pack(String nameOfPack, Werewolf leader) {

        this.nameOfPack = nameOfPack;
        this.leader = leader;
        this.witch = null;
    }


    /**
     *
     * Calls the name of the pack
     *
     */
    public String getNameOfPack() {

        return nameOfPack;
    }


    /**
     *
     * Sets the leader of the pack
     *
     * @param w  the w.
     */
    public void setLeader(Werewolf w) {

        leader = w;
    }


    /**
     *
     * Sets the witch variable
     *
     * @param w  the w.
     */
    public void setWitch(Witch w) {

        witch = w;
    }


    /**
     *
     * To string
     *
     */
    public String toString() {

        if (leader != null && witch != null)
            return nameOfPack + " led by " + leader.getName() + " with Witch " + witch.getName();
        else if (leader != null)
            return nameOfPack + " led by " + leader.getName();
        else if (witch != null)
            return nameOfPack + " with Witch " + witch.getName();
        else
            return nameOfPack;
    }
}
