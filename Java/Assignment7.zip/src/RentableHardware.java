/**
 * @Author: Husam Abdelhalim
 * @Date: April 11, 2024
 */
public abstract class RentableHardware extends TimsProduct {


    private double rentalCost;
    private boolean rented;


    /**
     *
     * Rentable hardware
     *
     * @param name  the name.
     * @param cost  the cost.
     * @param price  the price.
     * @param rentalCost  the rental cost.
     * @param rented  the rented.
     * @return public
     */
    public RentableHardware(String name, double cost, double price, double rentalCost, boolean rented) {

        super(name,cost,price);
        this.rentalCost = rentalCost;
        this.rented = rented;
    }


}
