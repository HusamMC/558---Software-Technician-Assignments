/**
 * @Author: Husam Abdelhalim
 * @Date: April 11, 2024
 */
public class BoxOfNails extends TimsProduct{

    private double size;
    private int quantity;


    /**
     *
     * Box of nails
     *
     * @param n  the name.
     * @param s  the size.
     * @param q  the quantity.
     * @param c  the cost.
     * @param p  the price.
     * @return private
     */
    private BoxOfNails(String n, double s, int q, double c, double p) {

        super(n, c, p);
        this.size = s;
        this.quantity = q;
    }


    /**
     *
     * Create a box of nails
     * and determines its name,
     * quantity, cost, price.
     *
     * @return BoxOfNails
     */
    public static BoxOfNails create() {


        String n = "Box of Nails";
        double s = 1;
        int q = 1;
        double c = 10.00;
        double p = 13.00;

        BoxOfNails b = new BoxOfNails(n, s, q, c, p);
        return b;
    }




    /**
     *
     * Gets the size
     *
     * @return the size
     */
    public double getSize() {

        return size;
    }


    /**
     *
     * Gets the quantity
     *
     * @return the quantity
     */
    public int getQuantity() {

        return quantity;
    }


    /**
     *
     * To string
     *
     * @return String
     */
    public String toString() {

        return getName();
    }

}
