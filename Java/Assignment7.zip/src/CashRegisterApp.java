/**
 * @Author: Husam Abdelhalim
 * @Date: April 11, 2024
 */
public class CashRegisterApp {
    public static void main(String[]args){
        TimsOrder t = TimsOrder.create();
        System.out.println(t);
        System.out.printf("Total Price: $%.2f\n", t.getAmountDue());

    }

}
