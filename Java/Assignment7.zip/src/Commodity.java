public interface Commodity {

    public double getProductionCost();
    public double getRetailPrice();

}
