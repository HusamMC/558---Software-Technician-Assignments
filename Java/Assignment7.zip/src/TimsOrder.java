import java.util.ArrayList;
import java.util.Scanner;


/**
 * @Author: Husam Abdelhalim
 * @Date: April 11, 2024
 */
public class TimsOrder {
    private int size;
    private String customerName;
    private ArrayList<TimsProduct> items;


    /**
     *
     * constructor which obtains the size
     * or timsproducts
     *
     * @param n  the n.
     * @param size  the size.
     */
    private TimsOrder(String n, int size){


        customerName = n;
        items = new ArrayList<TimsProduct>();
        this.size = items.size();

    }


    /**
     *
     * Sets the size
     *
     * @param s  the s.
     */
    public void setSize(int s) {

        size = s;
    }


    /**
     *
     * Gets the customer name
     *
     * @return the customer name
     */
    private String getCustomerName() {

        return customerName;
    }


    /**
     *
     * Constructor that creates
     * three classes which the customer
     * can purchase or rent.
     *
     */
    public static TimsOrder create() {

        Scanner scanner = new Scanner(System.in);
        String thing;
        System.out.println("Tim's Hardware Store\n");

        System.out.println("Enter customer name > \n");
        String customerName = scanner.nextLine();

        TimsOrder t = new TimsOrder(customerName, 1);

        while(true) {
            System.out.print("Item (e.g. nails or staples or gun or Q-quit) > \n");
            thing = scanner.nextLine();
            if(thing.equals("Q") || thing.equals("q")) break;

            if(thing.toUpperCase().equals("NAILS")) {
                t.items.add(BoxOfNails.create());
            } else if (thing.toUpperCase().equals("STAPLES")) {
                t.items.add(Staples.create());
            } else if (thing.toUpperCase().equals("GUN")) {
                TimsProduct product = NailGun.create();
                t.items.add(product );
                if(product instanceof RentableHardware) {
                    System.out.println("Rent item");
                }
            }


        }
        t.setSize( t.items.size() );
        return t;
    }



    /**
     *
     * Gets the amount due
     *
     * @return the amount due
     */
    public double getAmountDue() {

        double total = 0.0;
        for(TimsProduct p: items) {
            total += p.getRetailPrice();
        }
        return total;
    }


    /**
     *
     * To string that outputs the name and price
     * of the product
     *
     * @return String
     */
    public String toString() {

        String str = "Receipt \n";
        for(int i =0; i<items.size(); i++) {
            str += String.format(" %-3d, %-20s $%.2f\n",1 , items.get(i).getName(), items.get(i).getRetailPrice());
        }
        return str;
    }


}
