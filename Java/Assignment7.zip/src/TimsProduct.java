/**
 * @Author: Husam Abdelhalim
 * @Date: April 11, 2024
 */
public abstract class TimsProduct implements Commodity{
    private String name;
    private double cost;
    private double price;


    /**
     *
     * Tims product constructor
     * contains the name/cost/price variables
     *
     * @param n  the n.
     * @param c  the c.
     * @param p  the p.
     * @return public
     */
    public TimsProduct(String n, double c, double p) {

        name = n;
        cost = c;
        price = p;
    }



    /**
     *
     * Gets the name of the product
     *
     * @return the name
     */
    public String getName() {

        return name;
    }


    /**
     *
     * Gets the production cost
     *
     * @return the production cost
     */
    public double getProductionCost() {

        return cost;
    }


    /**
     *
     * Gets the retail price
     *
     * @return the retail price
     */
    public double getRetailPrice() {

        return price;
    }


    /**
     *
     * To string name of the product
     *
     * @return String
     */
    public String toString(){

        return name;
    }


}
