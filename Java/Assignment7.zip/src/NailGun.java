/**
 * @Author: Husam Abdelhalim
 * @Date: April 11, 2024
 */
public class NailGun extends RentableHardware {


    /**
     *
     * Nail gun constructor
     *
     * @param name  the name.
     * @param cost  the cost.
     * @param price  the price.
     * @param rented  the rented.
     * @param isRented  the is rented.
     * @return private
     */
    private NailGun(String name, double cost, double price, double rented, boolean isRented) {

        super(name, cost, price, rented, isRented);
    }


    /**
     *
     * Create the nailgun object
     * and determines its cost, price and rented value
     *
     * @return NailGun
     */
    public static NailGun create() {

        String name = "Nailgun";
        double cost = 80.00;
        double price = 100.00;
        double rented = 10.00;

        NailGun b = new NailGun(name, cost, price, rented, false);

        return b;

    }


    /**
     *
     * To string
     *
     * @return String
     */
    public String toString() {

        return "Nailgun";
    }


}
