/**
 * @Author: Husam Abdelhalim
 * @Date: April 11, 2024
 */
public class Staples extends TimsProduct{

    private double size;
    private int quantity;


    /**
     *
     * Staples constructor
     *
     * @param n  the name.
     * @param s  the size.
     * @param q  the quantity.
     * @param c  the cost.
     * @param p  the price.
     * @return private
     */
    private Staples(String n, double s, int q, double c, double p) {

        super(n, c, p);
        this.size = s;
        this.quantity = q;
    }


    /**
     *
     * Create the staples size, quantity,
     * cost and price.
     *
     * @return Staples
     */
    public static Staples create() {


        String n = "Box of Staples";
        double s = 1;
        int q = 1;
        double c = 8.00;
        double p = 10.00;

        Staples l = new Staples(n, s, q, c, p);
        return l;
    }




    /**
     *
     * Gets the size
     *
     * @return the size
     */
    public double getSize() {

        return size;
    }


    /**
     *
     * Gets the quantity
     *
     * @return the quantity
     */
    public int getQuantity() {

        return quantity;
    }


    /**
     *
     * To string
     *
     * @return String
     */
    public String toString() {

        return getName();
    }

}

