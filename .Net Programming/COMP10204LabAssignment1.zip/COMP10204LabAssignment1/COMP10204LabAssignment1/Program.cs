﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics.Eventing.Reader;

namespace COMP10204LabAssignment1
{
    
    public class Program
    {
        static Employee[] employees = new Employee[100];
        static void Main(string[] args)
        {
            String fileName = "employees.txt";

            FileInfo fileProps = new FileInfo(fileName);

            if (fileProps.Exists) {

                FileStream file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                StreamReader data = new StreamReader(file);
                String line;

                int count = 0;
                while ((line = data.ReadLine()) != null) {

                    String[] exploded = line.Split(',');

                    Employee emp = new Employee(exploded[0], Convert.ToInt32(exploded[1]), Convert.ToDecimal(exploded[2]), Convert.ToDouble(exploded[3]));
                    employees[count++] = emp;
                }

                data.Close();

                foreach (Employee employee in employees)
                {
                    if (employee != null)
                    {
                        Console.WriteLine(employee.ToString());
                    }
                }
            }
            else
            {
                Console.WriteLine("This file does not exist");
            }

            while (true)
            {
                Console.WriteLine("1.Sort by Employee Name(ascending)");
                Console.WriteLine("2.Sort by Employee Number(ascending)");
                Console.WriteLine("3.Sort by Employee Pay Rate(descending)");
                Console.WriteLine("4.Sort by Employee Hours(descending)");
                Console.WriteLine("5.Sort by Employee Gross Pay(descending)");
                Console.WriteLine("6.Exit");

                string reply = Console.ReadLine();

                switch(reply)
                {
                    case "1":

                        break;
                    case "2":

                        break;

                    case "3":

                        break;

                    case "4":

                        break;

                    case "5":

                        break;

                    case "6":

                        break;

                    default:
                        Console.WriteLine("Invalid Option");
                        break;
                }
                    
                    
            }
        }

    }
}
