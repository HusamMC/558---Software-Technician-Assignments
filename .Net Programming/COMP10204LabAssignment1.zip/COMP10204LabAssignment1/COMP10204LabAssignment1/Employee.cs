﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP10204LabAssignment1
{
    public class Employee
    {
        private String name;
        private int number;
        private decimal rate;
        private double hours;
        private decimal gross;

        public Employee(string name, int number, decimal rate, double hours)
        {
            this.name = name;
            this.number = number;
            this.rate = rate;
            this.hours = hours;
        }
        public decimal GetGross()
        {
            return gross;
        }
        public double GetHours()
        {
            return hours;
        }
        public String GetName()
        {
            return name;
        }
        public int GetNumber()
        {
            return number;
        }
        public decimal GetRate()
        {
            return rate;
        }
        public string toString()
        {
            return $"{name, 15} {number, 5} {rate, 6:C} {hours, 6}";
        }
        public double SetHours() { return hours; }
        public string SetName() {  return name; }
        public int SetNumber() {  return number; }
        public decimal SetRate() { return rate; }
    }
}
