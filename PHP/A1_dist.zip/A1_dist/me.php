<?php
# I Husam Abdelhalim, 000104532 certify that this material is my original work. No other person's work has been used without suitable acknowledgment and I have not made my work available to anyone else.

# @author Husam Abdelhalim, 000104532
# @package COMP 10260 Assignment 1 - Introduction to Server Side Programming

# Don't forget the statement of authorship!

?>
